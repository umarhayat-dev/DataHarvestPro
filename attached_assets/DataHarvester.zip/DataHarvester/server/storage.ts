import { 
  users,
  type User,
  type InsertUser,
  categories,
  type Category,
  type InsertCategory,
  courses,
  type Course,
  type InsertCourse,
  jobs,
  type Job,
  type InsertJob,
  careerApplications,
  type CareerApplication,
  type InsertCareerApplication,
  studentApplications,
  type StudentApplication,
  type InsertStudentApplication,
  testimonials,
  type Testimonial,
  type InsertTestimonial,
  contactMessages,
  type ContactMessage,
  type InsertContactMessage,
  teamMembers,
  type TeamMember,
  type InsertTeamMember
} from "@shared/schema";

import { db } from "./db";
import { eq, and, count, desc } from "drizzle-orm";

// Interface for all database operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Category operations
  getAllCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Course operations
  getAllCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  getCoursesByCategory(categoryId: number): Promise<Course[]>;
  getFeaturedCourses(): Promise<Course[]>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: number, course: InsertCourse): Promise<Course | undefined>;
  getCourseCount(): Promise<number>;
  
  // Job operations
  getActiveJobs(): Promise<Job[]>;
  getJob(id: number): Promise<Job | undefined>;
  createJob(job: InsertJob): Promise<Job>;
  updateJob(id: number, job: InsertJob): Promise<Job | undefined>;
  
  // Career application operations
  createCareerApplication(application: InsertCareerApplication): Promise<CareerApplication>;
  getAllCareerApplications(): Promise<CareerApplication[]>;
  getCareerApplication(id: number): Promise<CareerApplication | undefined>;
  updateCareerApplicationStatus(id: number, status: string, notes?: string): Promise<CareerApplication | undefined>;
  getCareerApplicationCount(): Promise<number>;
  
  // Student application operations
  createStudentApplication(application: InsertStudentApplication): Promise<StudentApplication>;
  getAllStudentApplications(): Promise<StudentApplication[]>;
  getStudentApplication(id: number): Promise<StudentApplication | undefined>;
  updateStudentApplicationStatus(id: number, status: string, notes?: string): Promise<StudentApplication | undefined>;
  getStudentApplicationCount(): Promise<number>;
  
  // Testimonial operations
  getActiveTestimonials(): Promise<Testimonial[]>;
  createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial>;
  
  // Contact message operations
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
  getAllContactMessages(): Promise<ContactMessage[]>;
  markContactMessageAsRead(id: number): Promise<ContactMessage | undefined>;
  getContactMessageCount(): Promise<number>;
  getUnreadContactMessageCount(): Promise<number>;
  
  // Team member operations
  getActiveTeamMembers(): Promise<TeamMember[]>;
  createTeamMember(member: InsertTeamMember): Promise<TeamMember>;
  updateTeamMember(id: number, member: InsertTeamMember): Promise<TeamMember | undefined>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Category operations
  async getAllCategories(): Promise<Category[]> {
    return await db.select().from(categories);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const [category] = await db.insert(categories).values(insertCategory).returning();
    return category;
  }

  // Course operations
  async getAllCourses(): Promise<Course[]> {
    return await db.select().from(courses);
  }

  async getCourse(id: number): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course;
  }

  async getCoursesByCategory(categoryId: number): Promise<Course[]> {
    return await db.select().from(courses).where(eq(courses.categoryId, categoryId));
  }

  async getFeaturedCourses(): Promise<Course[]> {
    return await db.select().from(courses).where(eq(courses.featured, true));
  }

  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const [course] = await db.insert(courses).values(insertCourse).returning();
    return course;
  }

  async updateCourse(id: number, updateCourse: InsertCourse): Promise<Course | undefined> {
    const [course] = await db
      .update(courses)
      .set({ ...updateCourse, updatedAt: new Date() })
      .where(eq(courses.id, id))
      .returning();
    return course;
  }

  async getCourseCount(): Promise<number> {
    const [result] = await db.select({ count: count() }).from(courses);
    return result.count;
  }

  // Job operations
  async getActiveJobs(): Promise<Job[]> {
    return await db.select().from(jobs).where(eq(jobs.isActive, true));
  }

  async getJob(id: number): Promise<Job | undefined> {
    const [job] = await db.select().from(jobs).where(eq(jobs.id, id));
    return job;
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const [job] = await db.insert(jobs).values(insertJob).returning();
    return job;
  }

  async updateJob(id: number, updateJob: InsertJob): Promise<Job | undefined> {
    const [job] = await db
      .update(jobs)
      .set({ ...updateJob, updatedAt: new Date() })
      .where(eq(jobs.id, id))
      .returning();
    return job;
  }

  // Career application operations
  async createCareerApplication(insertApplication: InsertCareerApplication): Promise<CareerApplication> {
    const [application] = await db.insert(careerApplications).values(insertApplication).returning();
    return application;
  }

  async getAllCareerApplications(): Promise<CareerApplication[]> {
    return await db.select().from(careerApplications).orderBy(desc(careerApplications.createdAt));
  }

  async getCareerApplication(id: number): Promise<CareerApplication | undefined> {
    const [application] = await db.select().from(careerApplications).where(eq(careerApplications.id, id));
    return application;
  }

  async updateCareerApplicationStatus(id: number, status: string, notes?: string): Promise<CareerApplication | undefined> {
    const [application] = await db
      .update(careerApplications)
      .set({ status, notes, updatedAt: new Date() })
      .where(eq(careerApplications.id, id))
      .returning();
    return application;
  }

  async getCareerApplicationCount(): Promise<number> {
    const [result] = await db.select({ count: count() }).from(careerApplications);
    return result.count;
  }

  // Student application operations
  async createStudentApplication(insertApplication: InsertStudentApplication): Promise<StudentApplication> {
    const [application] = await db.insert(studentApplications).values(insertApplication).returning();
    return application;
  }

  async getAllStudentApplications(): Promise<StudentApplication[]> {
    return await db.select().from(studentApplications).orderBy(desc(studentApplications.createdAt));
  }

  async getStudentApplication(id: number): Promise<StudentApplication | undefined> {
    const [application] = await db.select().from(studentApplications).where(eq(studentApplications.id, id));
    return application;
  }

  async updateStudentApplicationStatus(id: number, status: string, notes?: string): Promise<StudentApplication | undefined> {
    const [application] = await db
      .update(studentApplications)
      .set({ status, notes, updatedAt: new Date() })
      .where(eq(studentApplications.id, id))
      .returning();
    return application;
  }

  async getStudentApplicationCount(): Promise<number> {
    const [result] = await db.select({ count: count() }).from(studentApplications);
    return result.count;
  }

  // Testimonial operations
  async getActiveTestimonials(): Promise<Testimonial[]> {
    return await db.select().from(testimonials).where(eq(testimonials.isActive, true));
  }

  async createTestimonial(insertTestimonial: InsertTestimonial): Promise<Testimonial> {
    const [testimonial] = await db.insert(testimonials).values(insertTestimonial).returning();
    return testimonial;
  }

  // Contact message operations
  async createContactMessage(insertMessage: InsertContactMessage): Promise<ContactMessage> {
    const [message] = await db.insert(contactMessages).values(insertMessage).returning();
    return message;
  }

  async getAllContactMessages(): Promise<ContactMessage[]> {
    return await db.select().from(contactMessages).orderBy(desc(contactMessages.createdAt));
  }

  async markContactMessageAsRead(id: number): Promise<ContactMessage | undefined> {
    const [message] = await db
      .update(contactMessages)
      .set({ isRead: true, updatedAt: new Date() })
      .where(eq(contactMessages.id, id))
      .returning();
    return message;
  }

  async getContactMessageCount(): Promise<number> {
    const [result] = await db.select({ count: count() }).from(contactMessages);
    return result.count;
  }

  async getUnreadContactMessageCount(): Promise<number> {
    const [result] = await db
      .select({ count: count() })
      .from(contactMessages)
      .where(eq(contactMessages.isRead, false));
    return result.count;
  }

  // Team member operations
  async getActiveTeamMembers(): Promise<TeamMember[]> {
    return await db
      .select()
      .from(teamMembers)
      .where(eq(teamMembers.isActive, true))
      .orderBy(teamMembers.displayOrder);
  }

  async createTeamMember(insertMember: InsertTeamMember): Promise<TeamMember> {
    const [member] = await db.insert(teamMembers).values(insertMember).returning();
    return member;
  }

  async updateTeamMember(id: number, updateMember: InsertTeamMember): Promise<TeamMember | undefined> {
    const [member] = await db
      .update(teamMembers)
      .set({ ...updateMember, updatedAt: new Date() })
      .where(eq(teamMembers.id, id))
      .returning();
    return member;
  }
}

export const storage = new DatabaseStorage();
