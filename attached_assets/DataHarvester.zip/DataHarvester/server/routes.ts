import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema,
  insertCategorySchema,
  insertCourseSchema,
  insertJobSchema,
  insertCareerApplicationSchema,
  insertStudentApplicationSchema,
  insertTestimonialSchema,
  insertContactMessageSchema,
  insertTeamMemberSchema,
} from "@shared/schema";
import { ZodError } from "zod";
import bcrypt from 'bcryptjs';
import session from 'express-session';
import MemoryStore from 'memorystore';
import { isAdmin, isAuthenticated } from "./auth";

export async function registerRoutes(app: Express): Promise<Server> {
  // Session setup
  const MemoryStoreFactory = MemoryStore(session);
  app.use(
    session({
      cookie: { maxAge: 86400000 }, // 24 hours
      secret: process.env.SESSION_SECRET || 'alyusr-institute-secret',
      resave: false,
      saveUninitialized: false,
      store: new MemoryStoreFactory({
        checkPeriod: 86400000, // prune expired entries every 24h
      }),
    })
  );

  // User authentication routes
  app.post('/api/register', async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Hash password
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(userData.password, salt);
      
      // Create user with hashed password
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
      });
      
      // Don't return the password
      const { password, ...userWithoutPassword } = user;
      
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: 'Validation error', errors: error.errors });
      }
      console.error('Register error:', error);
      res.status(500).json({ message: 'Failed to register user' });
    }
  });

  app.post('/api/login', async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: 'Username and password are required' });
      }
      
      const user = await storage.getUserByUsername(username);
      
      if (!user) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
      
      const isPasswordValid = await bcrypt.compare(password, user.password);
      
      if (!isPasswordValid) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
      
      // Save user in session
      if (req.session) {
        req.session.user = {
          id: user.id,
          username: user.username,
          isAdmin: user.isAdmin,
        };
      }
      
      // Don't return the password
      const { password: _, ...userWithoutPassword } = user;
      
      res.json(userWithoutPassword);
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ message: 'Failed to log in' });
    }
  });

  app.post('/api/logout', (req, res) => {
    if (req.session) {
      req.session.destroy((err) => {
        if (err) {
          return res.status(500).json({ message: 'Failed to log out' });
        }
        res.json({ message: 'Logged out successfully' });
      });
    } else {
      res.json({ message: 'Already logged out' });
    }
  });

  app.get('/api/user', isAuthenticated, async (req, res) => {
    try {
      const { id } = req.session.user!;
      const user = await storage.getUser(id);
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Don't return the password
      const { password, ...userWithoutPassword } = user;
      
      res.json(userWithoutPassword);
    } catch (error) {
      console.error('Get user error:', error);
      res.status(500).json({ message: 'Failed to get user' });
    }
  });

  // Categories API
  app.get('/api/categories', async (_req, res) => {
    try {
      const categories = await storage.getAllCategories();
      res.json(categories);
    } catch (error) {
      console.error('Get categories error:', error);
      res.status(500).json({ message: 'Failed to get categories' });
    }
  });

  app.post('/api/categories', isAdmin, async (req, res) => {
    try {
      const categoryData = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(categoryData);
      res.status(201).json(category);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: 'Validation error', errors: error.errors });
      }
      console.error('Create category error:', error);
      res.status(500).json({ message: 'Failed to create category' });
    }
  });

  // Courses API
  app.get('/api/courses', async (req, res) => {
    try {
      const { categoryId } = req.query;
      let courses;
      
      if (categoryId && !isNaN(Number(categoryId))) {
        courses = await storage.getCoursesByCategory(Number(categoryId));
      } else {
        courses = await storage.getAllCourses();
      }
      
      res.json(courses);
    } catch (error) {
      console.error('Get courses error:', error);
      res.status(500).json({ message: 'Failed to get courses' });
    }
  });

  app.get('/api/courses/featured', async (_req, res) => {
    try {
      const featuredCourses = await storage.getFeaturedCourses();
      res.json(featuredCourses);
    } catch (error) {
      console.error('Get featured courses error:', error);
      res.status(500).json({ message: 'Failed to get featured courses' });
    }
  });

  app.get('/api/courses/:id', async (req, res) => {
    try {
      const id = Number(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid course ID' });
      }
      
      const course = await storage.getCourse(id);
      
      if (!course) {
        return res.status(404).json({ message: 'Course not found' });
      }
      
      res.json(course);
    } catch (error) {
      console.error('Get course error:', error);
      res.status(500).json({ message: 'Failed to get course' });
    }
  });

  app.post('/api/courses', isAdmin, async (req, res) => {
    try {
      const courseData = insertCourseSchema.parse(req.body);
      const course = await storage.createCourse(courseData);
      res.status(201).json(course);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: 'Validation error', errors: error.errors });
      }
      console.error('Create course error:', error);
      res.status(500).json({ message: 'Failed to create course' });
    }
  });

  app.put('/api/courses/:id', isAdmin, async (req, res) => {
    try {
      const id = Number(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid course ID' });
      }
      
      const courseData = insertCourseSchema.parse(req.body);
      const course = await storage.updateCourse(id, courseData);
      
      if (!course) {
        return res.status(404).json({ message: 'Course not found' });
      }
      
      res.json(course);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: 'Validation error', errors: error.errors });
      }
      console.error('Update course error:', error);
      res.status(500).json({ message: 'Failed to update course' });
    }
  });

  // Jobs API
  app.get('/api/jobs', async (_req, res) => {
    try {
      const jobs = await storage.getActiveJobs();
      res.json(jobs);
    } catch (error) {
      console.error('Get jobs error:', error);
      res.status(500).json({ message: 'Failed to get jobs' });
    }
  });

  app.get('/api/jobs/:id', async (req, res) => {
    try {
      const id = Number(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid job ID' });
      }
      
      const job = await storage.getJob(id);
      
      if (!job) {
        return res.status(404).json({ message: 'Job not found' });
      }
      
      res.json(job);
    } catch (error) {
      console.error('Get job error:', error);
      res.status(500).json({ message: 'Failed to get job' });
    }
  });

  app.post('/api/jobs', isAdmin, async (req, res) => {
    try {
      const jobData = insertJobSchema.parse(req.body);
      const job = await storage.createJob(jobData);
      res.status(201).json(job);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: 'Validation error', errors: error.errors });
      }
      console.error('Create job error:', error);
      res.status(500).json({ message: 'Failed to create job' });
    }
  });

  app.put('/api/jobs/:id', isAdmin, async (req, res) => {
    try {
      const id = Number(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid job ID' });
      }
      
      const jobData = insertJobSchema.parse(req.body);
      const job = await storage.updateJob(id, jobData);
      
      if (!job) {
        return res.status(404).json({ message: 'Job not found' });
      }
      
      res.json(job);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: 'Validation error', errors: error.errors });
      }
      console.error('Update job error:', error);
      res.status(500).json({ message: 'Failed to update job' });
    }
  });

  // Career Applications API
  app.post('/api/career-applications', async (req, res) => {
    try {
      const applicationData = insertCareerApplicationSchema.parse(req.body);
      const application = await storage.createCareerApplication(applicationData);
      res.status(201).json(application);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: 'Validation error', errors: error.errors });
      }
      console.error('Create career application error:', error);
      res.status(500).json({ message: 'Failed to create career application' });
    }
  });

  app.get('/api/career-applications', isAdmin, async (_req, res) => {
    try {
      const applications = await storage.getAllCareerApplications();
      res.json(applications);
    } catch (error) {
      console.error('Get career applications error:', error);
      res.status(500).json({ message: 'Failed to get career applications' });
    }
  });

  app.put('/api/career-applications/:id/status', isAdmin, async (req, res) => {
    try {
      const id = Number(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid application ID' });
      }
      
      const { status, notes } = req.body;
      
      if (!status || !['pending', 'reviewed', 'accepted', 'rejected'].includes(status)) {
        return res.status(400).json({ message: 'Invalid status' });
      }
      
      const application = await storage.updateCareerApplicationStatus(id, status, notes);
      
      if (!application) {
        return res.status(404).json({ message: 'Application not found' });
      }
      
      res.json(application);
    } catch (error) {
      console.error('Update career application status error:', error);
      res.status(500).json({ message: 'Failed to update career application status' });
    }
  });

  // Student Applications API
  app.post('/api/student-applications', async (req, res) => {
    try {
      const applicationData = insertStudentApplicationSchema.parse(req.body);
      const application = await storage.createStudentApplication(applicationData);
      res.status(201).json(application);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: 'Validation error', errors: error.errors });
      }
      console.error('Create student application error:', error);
      res.status(500).json({ message: 'Failed to create student application' });
    }
  });

  app.get('/api/student-applications', isAdmin, async (_req, res) => {
    try {
      const applications = await storage.getAllStudentApplications();
      res.json(applications);
    } catch (error) {
      console.error('Get student applications error:', error);
      res.status(500).json({ message: 'Failed to get student applications' });
    }
  });

  app.put('/api/student-applications/:id/status', isAdmin, async (req, res) => {
    try {
      const id = Number(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid application ID' });
      }
      
      const { status, notes } = req.body;
      
      if (!status || !['pending', 'enrolled', 'rejected'].includes(status)) {
        return res.status(400).json({ message: 'Invalid status' });
      }
      
      const application = await storage.updateStudentApplicationStatus(id, status, notes);
      
      if (!application) {
        return res.status(404).json({ message: 'Application not found' });
      }
      
      res.json(application);
    } catch (error) {
      console.error('Update student application status error:', error);
      res.status(500).json({ message: 'Failed to update student application status' });
    }
  });

  // Testimonials API
  app.get('/api/testimonials', async (_req, res) => {
    try {
      const testimonials = await storage.getActiveTestimonials();
      res.json(testimonials);
    } catch (error) {
      console.error('Get testimonials error:', error);
      res.status(500).json({ message: 'Failed to get testimonials' });
    }
  });

  app.post('/api/testimonials', isAdmin, async (req, res) => {
    try {
      const testimonialData = insertTestimonialSchema.parse(req.body);
      const testimonial = await storage.createTestimonial(testimonialData);
      res.status(201).json(testimonial);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: 'Validation error', errors: error.errors });
      }
      console.error('Create testimonial error:', error);
      res.status(500).json({ message: 'Failed to create testimonial' });
    }
  });

  // Contact Messages API
  app.post('/api/contact', async (req, res) => {
    try {
      const messageData = insertContactMessageSchema.parse(req.body);
      const message = await storage.createContactMessage(messageData);
      res.status(201).json(message);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: 'Validation error', errors: error.errors });
      }
      console.error('Create contact message error:', error);
      res.status(500).json({ message: 'Failed to create contact message' });
    }
  });

  app.get('/api/contact', isAdmin, async (_req, res) => {
    try {
      const messages = await storage.getAllContactMessages();
      res.json(messages);
    } catch (error) {
      console.error('Get contact messages error:', error);
      res.status(500).json({ message: 'Failed to get contact messages' });
    }
  });

  app.put('/api/contact/:id/read', isAdmin, async (req, res) => {
    try {
      const id = Number(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid message ID' });
      }
      
      const message = await storage.markContactMessageAsRead(id);
      
      if (!message) {
        return res.status(404).json({ message: 'Message not found' });
      }
      
      res.json(message);
    } catch (error) {
      console.error('Mark contact message as read error:', error);
      res.status(500).json({ message: 'Failed to mark contact message as read' });
    }
  });

  // Team Members API
  app.get('/api/team', async (_req, res) => {
    try {
      const teamMembers = await storage.getActiveTeamMembers();
      res.json(teamMembers);
    } catch (error) {
      console.error('Get team members error:', error);
      res.status(500).json({ message: 'Failed to get team members' });
    }
  });

  app.post('/api/team', isAdmin, async (req, res) => {
    try {
      const memberData = insertTeamMemberSchema.parse(req.body);
      const member = await storage.createTeamMember(memberData);
      res.status(201).json(member);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: 'Validation error', errors: error.errors });
      }
      console.error('Create team member error:', error);
      res.status(500).json({ message: 'Failed to create team member' });
    }
  });

  app.put('/api/team/:id', isAdmin, async (req, res) => {
    try {
      const id = Number(req.params.id);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid team member ID' });
      }
      
      const memberData = insertTeamMemberSchema.parse(req.body);
      const member = await storage.updateTeamMember(id, memberData);
      
      if (!member) {
        return res.status(404).json({ message: 'Team member not found' });
      }
      
      res.json(member);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: 'Validation error', errors: error.errors });
      }
      console.error('Update team member error:', error);
      res.status(500).json({ message: 'Failed to update team member' });
    }
  });

  // Admin Dashboard API
  app.get('/api/admin/stats', isAdmin, async (_req, res) => {
    try {
      const [
        courseCount,
        studentApplicationCount,
        careerApplicationCount,
        contactMessageCount,
        unreadContactMessageCount,
      ] = await Promise.all([
        storage.getCourseCount(),
        storage.getStudentApplicationCount(),
        storage.getCareerApplicationCount(),
        storage.getContactMessageCount(),
        storage.getUnreadContactMessageCount(),
      ]);
      
      res.json({
        courseCount,
        studentApplicationCount,
        careerApplicationCount,
        contactMessageCount,
        unreadContactMessageCount,
      });
    } catch (error) {
      console.error('Get admin stats error:', error);
      res.status(500).json({ message: 'Failed to get admin stats' });
    }
  });
  
  // User Profile API - for admin settings
  app.put('/api/user/profile', isAuthenticated, async (req, res) => {
    try {
      const { id } = req.session.user!;
      const { firstName, lastName, email } = req.body;
      
      // In a real implementation, you would update the user in the database
      // For now, we'll just return a success response
      res.json({
        id,
        firstName,
        lastName,
        email,
        message: 'Profile updated successfully',
      });
    } catch (error) {
      console.error('Update profile error:', error);
      res.status(500).json({ message: 'Failed to update profile' });
    }
  });
  
  // Change Password API - for admin settings
  app.put('/api/user/password', isAuthenticated, async (req, res) => {
    try {
      const { id } = req.session.user!;
      const { currentPassword, newPassword } = req.body;
      
      // In a real implementation, you would verify the current password and update with the new one
      // For now, we'll just return a success response
      res.json({
        message: 'Password changed successfully',
      });
    } catch (error) {
      console.error('Change password error:', error);
      res.status(500).json({ message: 'Failed to change password' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
