import { useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import JobCard from '@/components/ui/job-card';
import CareerApplicationForm from '@/components/forms/career-application-form';

export default function Career() {
  // Fetch active jobs
  const { data: jobs = [], isLoading: isLoadingJobs } = useQuery({
    queryKey: ['/api/jobs'],
  });

  // Scroll to the top on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <div className="bg-primary py-20 pattern-overlay">
        <div className="container mx-auto px-4">
          <div className="text-center text-white">
            <h1 className="font-heading text-4xl md:text-5xl font-bold">Career Opportunities</h1>
            <p className="text-white/80 mt-4 max-w-3xl mx-auto">
              Join our dedicated team of professionals and make a difference in Islamic education
            </p>
          </div>
        </div>
      </div>

      {/* Career Content Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h6 className="text-secondary text-sm font-medium uppercase tracking-wider">Career Opportunities</h6>
              <h2 className="font-heading text-3xl md:text-4xl font-bold text-neutral-600">Join Our Teaching Team</h2>
              <p className="text-neutral-500">
                We're always looking for qualified and passionate instructors to join our growing team. If you have expertise in Quranic recitation, Arabic language, or Islamic studies, we want to hear from you.
              </p>
              
              <div className="mt-8 space-y-6">
                <h3 className="font-heading text-2xl font-bold text-neutral-600">Current Openings</h3>
                
                {isLoadingJobs ? (
                  <div className="flex justify-center py-12">
                    <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
                  </div>
                ) : jobs && jobs.length > 0 ? (
                  <div className="space-y-6">
                    {jobs.map((job: any) => (
                      <JobCard
                        key={job.id}
                        title={job.title}
                        type={job.type}
                        description={job.description}
                        labelType={job.labelType}
                        requirements={job.qualifications.split(',').map((req: string) => req.trim())}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="bg-neutral-100 rounded-lg p-6">
                    <p className="text-neutral-500 text-center">No openings available at the moment. Please check back later or submit your application for future opportunities.</p>
                  </div>
                )}
              </div>

              <div className="mt-10 bg-neutral-100 rounded-lg p-6">
                <h3 className="font-heading text-xl font-bold text-neutral-600 mb-4">Why Join Alyusr Quran Institute?</h3>
                <ul className="space-y-3 text-neutral-500">
                  <li className="flex items-start">
                    <i className="fas fa-check-circle text-primary mt-1 mr-2"></i>
                    <span>Flexible working hours and fully remote positions</span>
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-check-circle text-primary mt-1 mr-2"></i>
                    <span>Competitive compensation based on experience and qualifications</span>
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-check-circle text-primary mt-1 mr-2"></i>
                    <span>Opportunity to impact students' lives globally</span>
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-check-circle text-primary mt-1 mr-2"></i>
                    <span>Continuous professional development and training</span>
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-check-circle text-primary mt-1 mr-2"></i>
                    <span>Be part of a supportive, values-driven organization</span>
                  </li>
                </ul>
              </div>
            </div>
            
            {/* Application Form */}
            <CareerApplicationForm jobs={jobs} isLoading={isLoadingJobs} />
          </div>
        </div>
      </section>

      {/* Join Our Team Section */}
      <section className="py-16 bg-neutral-100 pattern-overlay">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <img 
                src="https://pixabay.com/get/g047db1eac52551d162ede913950104f1fa8c8ddbabad210af9f0a0d5b70312234387d0697c5ed9e8568803c82b7f56ac8740cddc14e877e1bb1dcdb41de9e146_1280.jpg" 
                alt="Islamic education team" 
                className="rounded-lg shadow-lg object-cover w-full" 
              />
            </div>
            <div className="space-y-6">
              <h6 className="text-secondary text-sm font-medium uppercase tracking-wider">Our Culture</h6>
              <h2 className="font-heading text-3xl md:text-4xl font-bold text-neutral-600">Becoming Part of Our Team</h2>
              <p className="text-neutral-500">
                At Alyusr Quran Institute, we foster a culture of continuous learning, respect, and excellence. Our teachers and staff are united by a shared passion for spreading authentic Quranic knowledge and making a positive impact in our students' lives.
              </p>
              <div className="space-y-4 mt-6">
                <div className="flex items-start">
                  <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center mr-4 flex-shrink-0">
                    <span className="text-white font-bold">1</span>
                  </div>
                  <div>
                    <h3 className="font-heading text-lg font-bold text-neutral-600">Application Review</h3>
                    <p className="text-neutral-500 text-sm">
                      We carefully review all applications to find candidates with the right qualifications and passion.
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center mr-4 flex-shrink-0">
                    <span className="text-white font-bold">2</span>
                  </div>
                  <div>
                    <h3 className="font-heading text-lg font-bold text-neutral-600">Interview Process</h3>
                    <p className="text-neutral-500 text-sm">
                      Qualified candidates are invited for virtual interviews to discuss experience and teaching approach.
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center mr-4 flex-shrink-0">
                    <span className="text-white font-bold">3</span>
                  </div>
                  <div>
                    <h3 className="font-heading text-lg font-bold text-neutral-600">Demo Session</h3>
                    <p className="text-neutral-500 text-sm">
                      A short teaching demonstration helps us evaluate your instructional skills and techniques.
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center mr-4 flex-shrink-0">
                    <span className="text-white font-bold">4</span>
                  </div>
                  <div>
                    <h3 className="font-heading text-lg font-bold text-neutral-600">Onboarding</h3>
                    <p className="text-neutral-500 text-sm">
                      Selected candidates receive comprehensive training on our platform and teaching standards.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
