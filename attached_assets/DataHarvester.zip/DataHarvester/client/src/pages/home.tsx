import HeroSection from '@/components/ui/hero-section';
import KeyFeatures from '@/components/ui/key-features';
import CTASection from '@/components/ui/cta-section';
import CourseCard from '@/components/ui/course-card';
import TestimonialCard from '@/components/ui/testimonial-card';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';

export default function Home() {
  // Fetch featured courses
  const { data: featuredCourses, isLoading: isLoadingCourses } = useQuery({
    queryKey: ['/api/courses/featured'],
  });

  // Fetch testimonials
  const { data: testimonials, isLoading: isLoadingTestimonials } = useQuery({
    queryKey: ['/api/testimonials'],
  });

  const courseCategories = {
    'Tajweed': 'bg-primary',
    'Hifz': 'bg-secondary',
    'Arabic': 'bg-accent',
    'Translation': 'bg-primary-dark'
  };

  return (
    <>
      <HeroSection />
      
      <KeyFeatures />
      
      {/* Featured Courses Section */}
      <section id="courses" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h6 className="text-secondary text-sm font-medium uppercase tracking-wider">Our Programs</h6>
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-neutral-600 mt-2">Featured Quran Courses</h2>
            <p className="text-neutral-500 mt-4">Discover our comprehensive selection of courses designed to deepen your understanding of the Holy Quran.</p>
          </div>
          
          {/* Course Grid */}
          {isLoadingCourses ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
            </div>
          ) : (
            <>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {featuredCourses && featuredCourses.length > 0 ? (
                  featuredCourses.slice(0, 3).map((course: any) => (
                    <CourseCard
                      key={course.id}
                      id={course.id}
                      image={course.image}
                      category={course.categoryName || 'Quran'}
                      categoryColor={courseCategories[course.categoryName as keyof typeof courseCategories] || 'bg-primary'}
                      title={course.title}
                      description={course.description}
                      duration={course.duration}
                      rating={course.rating}
                      reviewCount={course.reviewCount}
                      instructorName={course.instructorName}
                      instructorTitle={course.instructorTitle}
                      instructorImage={course.instructorImage}
                      price={course.price}
                    />
                  ))
                ) : (
                  <div className="col-span-3 text-center py-8 bg-neutral-100 rounded-lg">
                    <p className="text-neutral-700 font-medium">No courses found. Check back soon for our upcoming programs.</p>
                  </div>
                )}
              </div>
              
              {/* View All Button */}
              <div className="text-center mt-12">
                <Link href="/courses">
                  <Button className="px-8 py-3 bg-primary text-white font-medium rounded-md hover:bg-primary-dark transition">
                    View All Courses <i className="fas fa-arrow-right ml-2"></i>
                  </Button>
                </Link>
              </div>
            </>
          )}
        </div>
      </section>
      
      {/* Testimonials Section */}
      <section id="testimonials" className="py-16 bg-primary pattern-overlay">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h6 className="text-white text-sm font-medium uppercase tracking-wider">Testimonials</h6>
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-white mt-2">What Our Students Say</h2>
            <p className="text-white/80 mt-4">Hear from our students about their learning experience with Alyusr Quran Institute.</p>
          </div>
          
          {isLoadingTestimonials ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-white"></div>
            </div>
          ) : (
            <div className="grid md:grid-cols-3 gap-8">
              {testimonials && testimonials.length > 0 ? (
                testimonials.slice(0, 3).map((testimonial: any) => (
                  <TestimonialCard
                    key={testimonial.id}
                    quote={testimonial.content}
                    name={testimonial.name}
                    title={testimonial.title}
                    image={testimonial.image}
                  />
                ))
              ) : (
                <div className="col-span-3 text-center py-8 bg-white/30 rounded-lg">
                  <p className="text-white font-medium text-lg">No testimonials yet. Be the first to share your experience!</p>
                </div>
              )}
            </div>
          )}
        </div>
      </section>
      
      <CTASection />
    </>
  );
}
