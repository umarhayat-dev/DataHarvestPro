import { useEffect } from 'react';
import ContactInfo from '@/components/ui/contact-info';
import ContactForm from '@/components/forms/contact-form';

export default function Contact() {
  // Scroll to the top on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <div className="bg-primary py-20 pattern-overlay">
        <div className="container mx-auto px-4">
          <div className="text-center text-white">
            <h1 className="font-heading text-4xl md:text-5xl font-bold">Contact Us</h1>
            <p className="text-white/80 mt-4 max-w-3xl mx-auto">
              Have questions about our courses or need assistance? Reach out to us and our team will get back to you soon.
            </p>
          </div>
        </div>
      </div>

      {/* Contact Section */}
      <section id="contact" className="py-16 bg-neutral-100">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12">
            <ContactForm />
            <ContactInfo />
          </div>
        </div>
      </section>

      {/* Map & Location Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h6 className="text-secondary text-sm font-medium uppercase tracking-wider">Our Presence</h6>
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-neutral-600 mt-2">Global Reach, Digital Access</h2>
            <p className="text-neutral-500 mt-4">
              While we operate primarily online to serve students worldwide, our administrative headquarters is based in a modern facility designed for digital education excellence.
            </p>
          </div>

          <div className="bg-neutral-100 p-8 rounded-lg pattern-overlay">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-globe-americas text-white text-2xl"></i>
              </div>
              <h3 className="font-heading text-xl font-bold text-neutral-600 mb-2">Serving Students in 45+ Countries</h3>
              <p className="text-neutral-500 max-w-2xl mx-auto">
                Our online platform allows us to bring quality Quranic education to students across North America, Europe, Asia, Africa, Australia, and beyond. No matter where you are, you can access our comprehensive Islamic education programs.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 mt-10">
              <div className="bg-white rounded-lg p-5 shadow-md text-center">
                <div className="w-12 h-12 rounded-full bg-primary-light/20 flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-clock text-primary text-xl"></i>
                </div>
                <h4 className="font-heading text-lg font-bold text-neutral-600 mb-1">Flexible Hours</h4>
                <p className="text-neutral-500 text-sm">
                  Classes available 24/7 across all time zones to accommodate your schedule
                </p>
              </div>

              <div className="bg-white rounded-lg p-5 shadow-md text-center">
                <div className="w-12 h-12 rounded-full bg-secondary-light/20 flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-laptop-house text-secondary text-xl"></i>
                </div>
                <h4 className="font-heading text-lg font-bold text-neutral-600 mb-1">Fully Remote</h4>
                <p className="text-neutral-500 text-sm">
                  Learn from the comfort of your home with our advanced online learning platform
                </p>
              </div>

              <div className="bg-white rounded-lg p-5 shadow-md text-center">
                <div className="w-12 h-12 rounded-full bg-accent-light/20 flex items-center justify-center mx-auto mb-3">
                  <i className="fas fa-headset text-accent text-xl"></i>
                </div>
                <h4 className="font-heading text-lg font-bold text-neutral-600 mb-1">24/7 Support</h4>
                <p className="text-neutral-500 text-sm">
                  Technical and administrative support available round the clock for all students
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-neutral-100">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h6 className="text-secondary text-sm font-medium uppercase tracking-wider">FAQs</h6>
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-neutral-600 mt-2">Frequently Asked Questions</h2>
            <p className="text-neutral-500 mt-4">
              Find answers to common questions about our courses, teaching methods, and enrollment process.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="bg-white rounded-lg p-6 shadow-md">
              <h3 className="font-heading text-xl font-bold text-neutral-600 mb-3">How do online Quran classes work?</h3>
              <p className="text-neutral-500">
                Our classes are conducted through video conferencing with screen-sharing capabilities. Students connect with their teachers at scheduled times for live, interactive lessons using our custom digital platform.
              </p>
            </div>

            <div className="bg-white rounded-lg p-6 shadow-md">
              <h3 className="font-heading text-xl font-bold text-neutral-600 mb-3">What is the duration of each course?</h3>
              <p className="text-neutral-500">
                Course durations vary based on the program and your learning pace. Tajweed courses typically take 3-6 months, while complete Hifz programs may take 2-3 years with consistent practice.
              </p>
            </div>

            <div className="bg-white rounded-lg p-6 shadow-md">
              <h3 className="font-heading text-xl font-bold text-neutral-600 mb-3">Can I schedule classes according to my time zone?</h3>
              <p className="text-neutral-500">
                Yes, we offer flexible scheduling to accommodate students from all time zones. You can choose class times that work best for your schedule, including evenings and weekends.
              </p>
            </div>

            <div className="bg-white rounded-lg p-6 shadow-md">
              <h3 className="font-heading text-xl font-bold text-neutral-600 mb-3">What age groups do you teach?</h3>
              <p className="text-neutral-500">
                We offer courses for all age groups, from children (5+ years) to adults. Our teaching methods are adapted to suit different age groups and learning capabilities.
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
