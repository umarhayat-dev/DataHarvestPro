import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import CourseCard from '@/components/ui/course-card';
import { Button } from '@/components/ui/button';

export default function Courses() {
  const [activeCategory, setActiveCategory] = useState<number | null>(null);
  
  // Fetch all categories
  const { data: categories = [], isLoading: isLoadingCategories } = useQuery({
    queryKey: ['/api/categories'],
  });
  
  // Fetch courses filtered by category if needed
  const { data: courses = [], isLoading: isLoadingCourses } = useQuery({
    queryKey: activeCategory ? ['/api/courses', { categoryId: activeCategory }] : ['/api/courses'],
  });
  
  const courseCategories = {
    'Tajweed': 'bg-primary',
    'Hifz': 'bg-secondary',
    'Arabic': 'bg-accent',
    'Translation': 'bg-primary-dark'
  };
  
  return (
    <>
      <div className="bg-primary py-20 pattern-overlay">
        <div className="container mx-auto px-4">
          <div className="text-center text-white">
            <h1 className="font-heading text-4xl md:text-5xl font-bold">Our Quran Courses</h1>
            <p className="text-white/80 mt-4 max-w-3xl mx-auto">
              Explore our comprehensive range of courses designed to help you connect with the Quran through proper recitation, memorization, and understanding.
            </p>
          </div>
        </div>
      </div>
      
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          {/* Course Filters */}
          <div className="flex flex-wrap justify-center gap-4 mb-10">
            <Button
              onClick={() => setActiveCategory(null)}
              className={!activeCategory ? 'bg-primary text-white' : 'bg-neutral-100 text-neutral-600 hover:bg-primary hover:text-white'}
            >
              All Courses
            </Button>
            
            {isLoadingCategories ? (
              <div className="animate-pulse w-24 h-10 bg-neutral-200 rounded-full"></div>
            ) : (
              categories.map((category: any) => (
                <Button
                  key={category.id}
                  onClick={() => setActiveCategory(category.id)}
                  className={activeCategory === category.id ? 'bg-primary text-white' : 'bg-neutral-100 text-neutral-600 hover:bg-primary hover:text-white'}
                >
                  {category.name}
                </Button>
              ))
            )}
          </div>
          
          {/* Course Grid */}
          {isLoadingCourses ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {courses && courses.length > 0 ? (
                courses.map((course: any) => (
                  <CourseCard
                    key={course.id}
                    id={course.id}
                    image={course.image}
                    category={course.categoryName || 'Quran'}
                    categoryColor={courseCategories[course.categoryName as keyof typeof courseCategories] || 'bg-primary'}
                    title={course.title}
                    description={course.description}
                    duration={course.duration}
                    rating={course.rating}
                    reviewCount={course.reviewCount}
                    instructorName={course.instructorName}
                    instructorTitle={course.instructorTitle}
                    instructorImage={course.instructorImage}
                    price={course.price}
                  />
                ))
              ) : (
                <div className="col-span-3 text-center py-8">
                  <p>No courses found in this category. Please check other categories or check back soon.</p>
                </div>
              )}
            </div>
          )}
        </div>
      </section>
    </>
  );
}
