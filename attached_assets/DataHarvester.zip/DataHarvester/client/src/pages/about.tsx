import { useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import TeamCard from '@/components/ui/team-card';
import CTASection from '@/components/ui/cta-section';

export default function About() {
  // Fetch team members
  const { data: teamMembers = [], isLoading: isLoadingTeam } = useQuery({
    queryKey: ['/api/team'],
  });

  // Scroll to the top on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <div className="bg-primary py-20 pattern-overlay">
        <div className="container mx-auto px-4">
          <div className="text-center text-white">
            <h1 className="font-heading text-4xl md:text-5xl font-bold">About Alyusr Quran Institute</h1>
            <p className="text-white/80 mt-4 max-w-3xl mx-auto">
              Dedicated to Excellence in Quranic Education Since 2008
            </p>
          </div>
        </div>
      </div>

      {/* About Section */}
      <section className="py-16 bg-neutral-100">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              {/* Islamic education images collage */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <img 
                    src="https://pixabay.com/get/g047db1eac52551d162ede913950104f1fa8c8ddbabad210af9f0a0d5b70312234387d0697c5ed9e8568803c82b7f56ac8740cddc14e877e1bb1dcdb41de9e146_1280.jpg" 
                    alt="Islamic education student" 
                    className="rounded-lg shadow-md h-40 w-full object-cover" 
                  />
                  <img 
                    src="https://pixabay.com/get/gff8b1e25c8f2e3f8ecb4a98650a0be8612c051cb9da24aa0d74ddd1b2f74af7c017e8f9e58e3900d2ee68dd115ddc0105c85e90073637a5626728f299bcc3147_1280.jpg" 
                    alt="Islamic calligraphy" 
                    className="rounded-lg shadow-md h-64 w-full object-cover" 
                  />
                </div>
                <div className="space-y-4 mt-6">
                  <img 
                    src="https://pixabay.com/get/ga042e54cd910f34e1002b52b8a7f77a17bf7d63cab364e86f925110609b546a030f1ab56d7c082262485604109d173d77810c483cb8dc9433baf8fccbb5af9c8_1280.jpg" 
                    alt="Modern mosque interior" 
                    className="rounded-lg shadow-md h-64 w-full object-cover" 
                  />
                  <img 
                    src="https://pixabay.com/get/gd0129ea4bfb8363e4747619c07904a3797288b3416411efc017a4239c9d6733a48cb2e4169cc7d5617383a25268e1ae01d41479509c5ea8fa4ea8a957053b027_1280.jpg" 
                    alt="Quran study session" 
                    className="rounded-lg shadow-md h-40 w-full object-cover" 
                  />
                </div>
              </div>
            </div>
            <div className="space-y-6">
              <h6 className="text-secondary text-sm font-medium uppercase tracking-wider">About Us</h6>
              <h2 className="font-heading text-3xl md:text-4xl font-bold text-neutral-600">
                Dedicated to Excellence in Quranic Education
              </h2>
              <p className="text-neutral-500">
                Alyusr Quran Institute was founded with a vision to make authentic Quranic education accessible to Muslims worldwide. 
                We combine traditional ijazah-based teaching methods with modern technology to deliver an immersive learning experience.
              </p>
              <div className="grid grid-cols-2 gap-6 mt-8">
                <div className="flex items-start">
                  <div className="w-12 h-12 rounded-full bg-primary-light/20 flex items-center justify-center mr-4 flex-shrink-0">
                    <i className="fas fa-book-open text-primary text-xl"></i>
                  </div>
                  <div>
                    <h3 className="font-heading text-lg font-bold text-neutral-600">Our Mission</h3>
                    <p className="text-neutral-500 text-sm mt-1">
                      To make the Quran accessible to all Muslims through authentic, flexible, and engaging online education.
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-12 h-12 rounded-full bg-secondary-light/20 flex items-center justify-center mr-4 flex-shrink-0">
                    <i className="fas fa-eye text-secondary text-xl"></i>
                  </div>
                  <div>
                    <h3 className="font-heading text-lg font-bold text-neutral-600">Our Vision</h3>
                    <p className="text-neutral-500 text-sm mt-1">
                      To become the world's leading platform for comprehensive Quranic education and Arabic language learning.
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-12 h-12 rounded-full bg-accent-light/20 flex items-center justify-center mr-4 flex-shrink-0">
                    <i className="fas fa-medal text-accent text-xl"></i>
                  </div>
                  <div>
                    <h3 className="font-heading text-lg font-bold text-neutral-600">Experience</h3>
                    <p className="text-neutral-500 text-sm mt-1">
                      Over 15 years of teaching experience with students from 45+ countries globally.
                    </p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-12 h-12 rounded-full bg-primary-dark/20 flex items-center justify-center mr-4 flex-shrink-0">
                    <i className="fas fa-users text-primary-dark text-xl"></i>
                  </div>
                  <div>
                    <h3 className="font-heading text-lg font-bold text-neutral-600">Community</h3>
                    <p className="text-neutral-500 text-sm mt-1">
                      A global community of 2,500+ students and alumni supporting each other in their Quranic journey.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our History */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h6 className="text-secondary text-sm font-medium uppercase tracking-wider">Our Journey</h6>
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-neutral-600 mt-2">Our History</h2>
            <p className="text-neutral-500 mt-4">
              Alyusr Quran Institute was established in 2008 with a mission to provide authentic Quranic education to Muslims around the world. 
              What started as a small initiative with just a handful of students has grown into a global educational platform.
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold">2008</span>
              </div>
              <h3 className="font-heading text-lg font-bold text-neutral-600 mb-2">Foundation</h3>
              <p className="text-neutral-500 text-sm">
                Established with a small team of 3 scholars teaching Tajweed and basic Quran reading
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold">2012</span>
              </div>
              <h3 className="font-heading text-lg font-bold text-neutral-600 mb-2">Expansion</h3>
              <p className="text-neutral-500 text-sm">
                Added Arabic language and Hifz programs with dedicated teachers for each course
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold">2016</span>
              </div>
              <h3 className="font-heading text-lg font-bold text-neutral-600 mb-2">Innovation</h3>
              <p className="text-neutral-500 text-sm">
                Launched our custom digital learning platform with interactive Quran study tools
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold">Today</span>
              </div>
              <h3 className="font-heading text-lg font-bold text-neutral-600 mb-2">Global Reach</h3>
              <p className="text-neutral-500 text-sm">
                Serving 2,500+ students across 45+ countries with a team of certified scholars
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Digital Learning Facilities */}
      <section className="py-16 bg-neutral-100 pattern-overlay">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h6 className="text-secondary text-sm font-medium uppercase tracking-wider">Our Platform</h6>
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-neutral-600 mt-2">Digital Learning Facilities</h2>
            <p className="text-neutral-500 mt-4">
              Our state-of-the-art online learning environment provides everything you need for an effective and engaging Quranic education.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition">
              <div className="w-14 h-14 rounded-full bg-primary-light/20 flex items-center justify-center mb-4">
                <i className="fas fa-video text-primary text-xl"></i>
              </div>
              <h3 className="font-heading text-xl font-bold text-neutral-600 mb-2">Live Video Classes</h3>
              <p className="text-neutral-500">
                High-quality video conferencing with screen sharing and digital Quran viewing for an interactive learning experience.
              </p>
            </div>

            <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition">
              <div className="w-14 h-14 rounded-full bg-secondary-light/20 flex items-center justify-center mb-4">
                <i className="fas fa-book-reader text-secondary text-xl"></i>
              </div>
              <h3 className="font-heading text-xl font-bold text-neutral-600 mb-2">Digital Quran Library</h3>
              <p className="text-neutral-500">
                Access to various Quranic texts, translations, and tafsir resources to enhance your understanding.
              </p>
            </div>

            <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition">
              <div className="w-14 h-14 rounded-full bg-accent-light/20 flex items-center justify-center mb-4">
                <i className="fas fa-headphones text-accent text-xl"></i>
              </div>
              <h3 className="font-heading text-xl font-bold text-neutral-600 mb-2">Audio Recording Tools</h3>
              <p className="text-neutral-500">
                Record and playback your recitation for practice and receive detailed feedback from your instructor.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h6 className="text-secondary text-sm font-medium uppercase tracking-wider">Our Team</h6>
            <h2 className="font-heading text-3xl md:text-4xl font-bold text-neutral-600 mt-2">Meet Our Expert Instructors</h2>
            <p className="text-neutral-500 mt-4">
              Our teachers are certified Quran and Arabic instructors with years of experience in Islamic education.
            </p>
          </div>
          
          {isLoadingTeam ? (
            <div className="flex justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {teamMembers && teamMembers.length > 0 ? (
                teamMembers.map((member: any) => (
                  <TeamCard
                    key={member.id}
                    name={member.name}
                    title={member.title}
                    bio={member.bio}
                    image={member.image}
                    socialLinks={{
                      twitter: member.socialTwitter,
                      linkedin: member.socialLinkedin,
                      facebook: member.socialFacebook,
                      instagram: member.socialInstagram,
                      youtube: member.socialYoutube
                    }}
                  />
                ))
              ) : (
                // Fallback to default team members if none are returned from API
                <>
                  <TeamCard
                    name="Sheikh Ahmad"
                    title="Tajweed Instructor"
                    bio="Certified with Ijazah in the 10 Qira'at from Al-Azhar University."
                    image="https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400"
                    socialLinks={{
                      twitter: "#",
                      linkedin: "#",
                      facebook: "#"
                    }}
                  />
                  <TeamCard
                    name="Ustadha Aisha"
                    title="Arabic Instructor"
                    bio="Masters in Arabic linguistics with 10+ years of teaching experience."
                    image="https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400"
                    socialLinks={{
                      twitter: "#",
                      linkedin: "#",
                      instagram: "#"
                    }}
                  />
                  <TeamCard
                    name="Ustadh Mohammed"
                    title="Hifz Specialist"
                    bio="Hafiz of the Quran with special training in memory techniques."
                    image="https://images.unsplash.com/photo-1566753323558-f4e0952af115?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400"
                    socialLinks={{
                      youtube: "#",
                      linkedin: "#",
                      facebook: "#"
                    }}
                  />
                  <TeamCard
                    name="Dr. Ibrahim"
                    title="Tafsir Specialist"
                    bio="PhD in Quranic Studies specializing in contemporary interpretations."
                    image="https://images.unsplash.com/photo-1607346256330-dee7af15f7c5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400"
                    socialLinks={{
                      twitter: "#",
                      linkedin: "#",
                      facebook: "#"
                    }}
                  />
                </>
              )}
            </div>
          )}
        </div>
      </section>

      <CTASection />
    </>
  );
}
