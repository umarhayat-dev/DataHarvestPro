import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { format } from 'date-fns';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from '@/components/ui/badge';
import AdminSidebar from '@/components/admin/sidebar';
import { Loader2, Eye, Search, CheckCircle2 } from 'lucide-react';

export default function AdminMessages() {
  const [location] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMessage, setViewMessage] = useState<any | null>(null);
  const [replyMessage, setReplyMessage] = useState('');
  
  // Scroll to the top on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Fetch all contact messages
  const { data: messages = [], isLoading } = useQuery<any[]>({
    queryKey: ['/api/contact'],
  });

  // Mark message as read mutation
  const markAsReadMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest('PUT', `/api/contact/${id}/read`, {});
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/contact'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/stats'] });
      
      toast({
        title: "Message marked as read",
        description: "The message has been marked as read.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update message",
        description: error.message || "An error occurred while updating the message",
        variant: "destructive",
      });
    },
  });

  // Filter messages based on search term
  const filteredMessages = Array.isArray(messages) ? messages.filter((message: any) => {
    return (
      message.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      message.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      message.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
      message.message.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }) : [];

  // Handle viewing message details
  const handleViewMessage = (message: any) => {
    setViewMessage(message);
    
    // If message is not read, mark it as read
    if (!message.isRead) {
      markAsReadMutation.mutate(message.id);
    }
  };

  // Handle replying to message
  const handleReply = () => {
    if (!viewMessage) return;
    
    // In a real application, you would call an API to send the reply
    // Here we're just showing a toast notification
    toast({
      title: "Reply sent",
      description: `Your reply has been sent to ${viewMessage.email}.`,
    });
    
    setReplyMessage('');
    setViewMessage(null);
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="flex">
        <AdminSidebar activePath={location} />
        
        <div className="flex-1 p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-heading font-bold text-neutral-800">Contact Messages</h1>
            <p className="text-neutral-500">Manage messages from website visitors</p>
          </div>
          
          <div className="mb-6">
            <div className="relative max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400" />
              <Input
                placeholder="Search messages..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          
          <Card>
            <CardContent className="p-0">
              {isLoading ? (
                <div className="flex items-center justify-center h-64">
                  <Loader2 className="h-8 w-8 text-primary animate-spin" />
                  <span className="ml-2">Loading messages...</span>
                </div>
              ) : filteredMessages.length === 0 ? (
                <div className="p-6 text-center text-neutral-500">
                  <p>No messages found</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[200px]">Sender</TableHead>
                      <TableHead>Subject</TableHead>
                      <TableHead className="w-[180px]">Received</TableHead>
                      <TableHead className="w-[100px]">Status</TableHead>
                      <TableHead className="w-[80px]">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredMessages.map((message: any) => (
                      <TableRow key={message.id} className={!message.isRead ? "bg-blue-50/50" : ""}>
                        <TableCell>
                          <div>
                            <p className="font-medium">{message.name}</p>
                            <p className="text-sm text-neutral-500">{message.email}</p>
                          </div>
                        </TableCell>
                        <TableCell>
                          <p className={!message.isRead ? "font-medium" : ""}>
                            {message.subject}
                          </p>
                        </TableCell>
                        <TableCell>
                          <p className="text-sm text-neutral-500">
                            {format(new Date(message.createdAt), 'MMM d, yyyy')}
                          </p>
                        </TableCell>
                        <TableCell>
                          <Badge variant={message.isRead ? "outline" : "default"}>
                            {message.isRead ? "Read" : "New"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleViewMessage(message)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
          
          {/* Message view dialog */}
          {viewMessage && (
            <Dialog open={!!viewMessage} onOpenChange={(open) => !open && setViewMessage(null)}>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle>{viewMessage.subject}</DialogTitle>
                  <DialogDescription>
                    From: {viewMessage.name} ({viewMessage.email})
                  </DialogDescription>
                </DialogHeader>
                
                <div className="py-4">
                  <div className="bg-neutral-50 p-4 rounded-lg whitespace-pre-wrap">
                    {viewMessage.message}
                  </div>
                  
                  <div className="mt-6 space-y-2">
                    <h4 className="text-sm font-medium">Reply to this message:</h4>
                    <Textarea
                      placeholder="Type your reply here..."
                      rows={5}
                      value={replyMessage}
                      onChange={(e) => setReplyMessage(e.target.value)}
                    />
                  </div>
                </div>
                
                <DialogFooter>
                  <Button variant="outline" onClick={() => setViewMessage(null)}>
                    Close
                  </Button>
                  <Button
                    onClick={handleReply}
                    disabled={!replyMessage.trim()}
                  >
                    <CheckCircle2 className="mr-2 h-4 w-4" /> Send Reply
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>
    </div>
  );
}