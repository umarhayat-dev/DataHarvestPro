import { useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';
import AdminSidebar from '@/components/admin/sidebar';
import StatCard from '@/components/admin/stat-card';
import { useAuth } from '@/hooks/use-auth';
import { useLocation } from 'wouter';
import { Loader2 } from 'lucide-react';

export default function AdminDashboard() {
  const [location] = useLocation();
  const { isAdmin, isLoading: isAuthLoading } = useAuth();

  // Scroll to the top on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Fetch dashboard stats
  const { data: stats, isLoading: isStatsLoading } = useQuery({
    queryKey: ['/api/admin/stats'],
    enabled: isAdmin,
  });

  const isLoading = isAuthLoading || isStatsLoading;

  // Demo data for charts (will be replaced with actual data)
  const applicationStatusData = [
    { name: 'Pending', value: stats?.studentApplicationCount?.pending || 12, color: '#f59e0b' },
    { name: 'Enrolled', value: stats?.studentApplicationCount?.enrolled || 24, color: '#10b981' },
    { name: 'Rejected', value: stats?.studentApplicationCount?.rejected || 8, color: '#ef4444' },
  ];

  const courseEnrollmentData = [
    { name: 'Tajweed', enrolled: 35, target: 50 },
    { name: 'Hifz', enrolled: 28, target: 40 },
    { name: 'Arabic', enrolled: 42, target: 45 },
    { name: 'Translation', enrolled: 31, target: 40 },
  ];

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="flex">
        <AdminSidebar activePath={location} />
        
        <div className="flex-1 p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-heading font-bold text-neutral-800">Admin Dashboard</h1>
            <p className="text-neutral-500">Overview of your institute's performance and activities</p>
          </div>
          
          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <Loader2 className="h-8 w-8 text-primary animate-spin" />
              <span className="ml-2">Loading dashboard data...</span>
            </div>
          ) : (
            <>
              {/* Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <StatCard 
                  title="Total Courses" 
                  value={stats?.courseCount || 0} 
                  icon="fas fa-book" 
                  colorClass="bg-primary-light/20 text-primary"
                  change={{ value: "+5", text: "from last month" }}
                />
                <StatCard 
                  title="Student Applications" 
                  value={stats?.studentApplicationCount || 0} 
                  icon="fas fa-user-graduate" 
                  colorClass="bg-secondary-light/20 text-secondary"
                  change={{ value: "+12", text: "from last month" }}
                />
                <StatCard 
                  title="Career Applications" 
                  value={stats?.careerApplicationCount || 0} 
                  icon="fas fa-user-tie" 
                  colorClass="bg-accent-light/20 text-accent"
                  change={{ value: "+3", text: "from last month" }}
                />
                <StatCard 
                  title="Unread Messages" 
                  value={stats?.unreadContactMessageCount || 0} 
                  icon="fas fa-envelope" 
                  colorClass="bg-amber-100 text-amber-600"
                  change={{ value: "-2", text: "from yesterday" }}
                />
              </div>
              
              {/* Charts */}
              <Tabs defaultValue="overview" className="w-full">
                <TabsList className="mb-6">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="enrollments">Enrollments</TabsTrigger>
                  <TabsTrigger value="applications">Applications</TabsTrigger>
                </TabsList>
                
                <TabsContent value="overview" className="space-y-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Card>
                      <CardContent className="p-6">
                        <h3 className="text-lg font-heading font-bold mb-4">Application Status</h3>
                        <div className="h-64">
                          <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                              <Pie
                                data={applicationStatusData}
                                cx="50%"
                                cy="50%"
                                labelLine={false}
                                outerRadius={80}
                                fill="#8884d8"
                                dataKey="value"
                                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                              >
                                {applicationStatusData.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={entry.color} />
                                ))}
                              </Pie>
                              <Legend />
                            </PieChart>
                          </ResponsiveContainer>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-6">
                        <h3 className="text-lg font-heading font-bold mb-4">Recent Activity</h3>
                        <div className="space-y-4">
                          <div className="flex items-start pb-4 border-b border-neutral-100">
                            <div className="w-10 h-10 rounded-full bg-primary-light/20 flex items-center justify-center mr-3 flex-shrink-0">
                              <i className="fas fa-user-plus text-primary"></i>
                            </div>
                            <div>
                              <p className="text-neutral-700 font-medium">New Student Application</p>
                              <p className="text-sm text-neutral-500">Ahmed S. applied for Tajweed course</p>
                              <p className="text-xs text-neutral-400 mt-1">2 hours ago</p>
                            </div>
                          </div>
                          
                          <div className="flex items-start pb-4 border-b border-neutral-100">
                            <div className="w-10 h-10 rounded-full bg-secondary-light/20 flex items-center justify-center mr-3 flex-shrink-0">
                              <i className="fas fa-envelope text-secondary"></i>
                            </div>
                            <div>
                              <p className="text-neutral-700 font-medium">New Contact Message</p>
                              <p className="text-sm text-neutral-500">Sarah M. sent a question about Hifz program</p>
                              <p className="text-xs text-neutral-400 mt-1">4 hours ago</p>
                            </div>
                          </div>
                          
                          <div className="flex items-start pb-4 border-b border-neutral-100">
                            <div className="w-10 h-10 rounded-full bg-accent-light/20 flex items-center justify-center mr-3 flex-shrink-0">
                              <i className="fas fa-user-tie text-accent"></i>
                            </div>
                            <div>
                              <p className="text-neutral-700 font-medium">New Career Application</p>
                              <p className="text-sm text-neutral-500">Mohammed K. applied for Arabic Teacher position</p>
                              <p className="text-xs text-neutral-400 mt-1">1 day ago</p>
                            </div>
                          </div>
                          
                          <div className="flex items-start">
                            <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mr-3 flex-shrink-0">
                              <i className="fas fa-check-circle text-green-600"></i>
                            </div>
                            <div>
                              <p className="text-neutral-700 font-medium">Student Enrollment Confirmed</p>
                              <p className="text-sm text-neutral-500">Fatima H. enrolled in Quran Translation course</p>
                              <p className="text-xs text-neutral-400 mt-1">2 days ago</p>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
                
                <TabsContent value="enrollments">
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="text-lg font-heading font-bold mb-4">Course Enrollments</h3>
                      <div className="h-80">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={courseEnrollmentData}
                            margin={{
                              top: 20,
                              right: 30,
                              left: 20,
                              bottom: 5,
                            }}
                          >
                            <XAxis dataKey="name" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Bar dataKey="enrolled" fill="#2e7d32" name="Current Enrollments" />
                            <Bar dataKey="target" fill="#d81b60" name="Enrollment Target" />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="applications">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Card>
                      <CardContent className="p-6">
                        <h3 className="text-lg font-heading font-bold mb-4">Student Applications</h3>
                        <div className="space-y-4">
                          <div className="flex justify-between pb-3 border-b border-neutral-100">
                            <span className="text-neutral-700 font-medium">Total Applications</span>
                            <span className="font-bold text-primary">{stats?.studentApplicationCount || 0}</span>
                          </div>
                          <div className="flex justify-between pb-3 border-b border-neutral-100">
                            <span className="text-neutral-700">Pending Review</span>
                            <span className="font-medium text-amber-500">{stats?.studentApplicationCount?.pending || 12}</span>
                          </div>
                          <div className="flex justify-between pb-3 border-b border-neutral-100">
                            <span className="text-neutral-700">Accepted</span>
                            <span className="font-medium text-green-600">{stats?.studentApplicationCount?.enrolled || 24}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-neutral-700">Rejected</span>
                            <span className="font-medium text-red-500">{stats?.studentApplicationCount?.rejected || 8}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-6">
                        <h3 className="text-lg font-heading font-bold mb-4">Career Applications</h3>
                        <div className="space-y-4">
                          <div className="flex justify-between pb-3 border-b border-neutral-100">
                            <span className="text-neutral-700 font-medium">Total Applications</span>
                            <span className="font-bold text-primary">{stats?.careerApplicationCount || 0}</span>
                          </div>
                          <div className="flex justify-between pb-3 border-b border-neutral-100">
                            <span className="text-neutral-700">Pending Review</span>
                            <span className="font-medium text-amber-500">{stats?.careerApplicationCount?.pending || 6}</span>
                          </div>
                          <div className="flex justify-between pb-3 border-b border-neutral-100">
                            <span className="text-neutral-700">Scheduled for Interview</span>
                            <span className="font-medium text-blue-500">{stats?.careerApplicationCount?.reviewed || 4}</span>
                          </div>
                          <div className="flex justify-between pb-3 border-b border-neutral-100">
                            <span className="text-neutral-700">Accepted</span>
                            <span className="font-medium text-green-600">{stats?.careerApplicationCount?.accepted || 3}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-neutral-700">Rejected</span>
                            <span className="font-medium text-red-500">{stats?.careerApplicationCount?.rejected || 2}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
              </Tabs>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
