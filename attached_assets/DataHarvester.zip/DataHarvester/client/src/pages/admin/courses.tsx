import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle,
  DialogTrigger
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import AdminSidebar from '@/components/admin/sidebar';
import { Loader2, Pencil, Plus, TrashIcon, AlertCircle, CheckCircle } from 'lucide-react';

// Form schema for adding/editing courses
const courseFormSchema = z.object({
  title: z.string().min(3, { message: "Title must be at least 3 characters" }),
  slug: z.string().min(3, { message: "Slug must be at least 3 characters" }),
  description: z.string().min(10, { message: "Description must be at least 10 characters" }),
  price: z.coerce.number().min(0, { message: "Price cannot be negative" }),
  duration: z.string().min(2, { message: "Duration is required" }),
  image: z.string().url({ message: "Valid image URL is required" }),
  categoryId: z.coerce.number().min(1, { message: "Category is required" }),
  instructorName: z.string().min(2, { message: "Instructor name is required" }),
  instructorTitle: z.string().min(2, { message: "Instructor title is required" }),
  instructorImage: z.string().url({ message: "Valid instructor image URL is required" }),
  featured: z.boolean().default(false),
});

export default function AdminCourses() {
  const [location] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isEditMode, setIsEditMode] = useState(false);
  const [currentCourseId, setCurrentCourseId] = useState<number | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [courseToDelete, setCourseToDelete] = useState<number | null>(null);

  // Scroll to the top on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Fetch all courses
  const { data: courses = [], isLoading: isLoadingCourses } = useQuery({
    queryKey: ['/api/courses'],
  });

  // Fetch all categories
  const { data: categories = [], isLoading: isLoadingCategories } = useQuery({
    queryKey: ['/api/categories'],
  });

  // Form for adding/editing courses
  const form = useForm<z.infer<typeof courseFormSchema>>({
    resolver: zodResolver(courseFormSchema),
    defaultValues: {
      title: "",
      slug: "",
      description: "",
      price: 0,
      duration: "",
      image: "",
      categoryId: 0,
      instructorName: "",
      instructorTitle: "",
      instructorImage: "",
      featured: false,
    },
  });

  // Reset form when dialog closes
  useEffect(() => {
    if (!isDialogOpen) {
      form.reset();
      setIsEditMode(false);
      setCurrentCourseId(null);
    }
  }, [isDialogOpen, form]);

  // Mutation for adding a new course
  const addCourseMutation = useMutation({
    mutationFn: async (data: z.infer<typeof courseFormSchema>) => {
      // Convert price to cents for storage
      const courseData = { ...data, price: data.price * 100 };
      const res = await apiRequest('POST', '/api/courses', courseData);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Course added",
        description: "The course has been added successfully",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/courses'] });
      setIsDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add course",
        description: error.message || "An error occurred while adding the course",
        variant: "destructive",
      });
    },
  });

  // Mutation for editing a course
  const editCourseMutation = useMutation({
    mutationFn: async (data: z.infer<typeof courseFormSchema> & { id: number }) => {
      const { id, ...courseData } = data;
      // Convert price to cents for storage
      const updatedData = { ...courseData, price: courseData.price * 100 };
      const res = await apiRequest('PUT', `/api/courses/${id}`, updatedData);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Course updated",
        description: "The course has been updated successfully",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/courses'] });
      setIsDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update course",
        description: error.message || "An error occurred while updating the course",
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  function onSubmit(values: z.infer<typeof courseFormSchema>) {
    if (isEditMode && currentCourseId) {
      editCourseMutation.mutate({ ...values, id: currentCourseId });
    } else {
      addCourseMutation.mutate(values);
    }
  }

  // Function to set up edit mode and pre-fill form
  function editCourse(course: any) {
    setIsEditMode(true);
    setCurrentCourseId(course.id);
    
    form.reset({
      title: course.title,
      slug: course.slug,
      description: course.description,
      // Convert price from cents to dollars for display
      price: course.price / 100,
      duration: course.duration,
      image: course.image,
      categoryId: course.categoryId,
      instructorName: course.instructorName,
      instructorTitle: course.instructorTitle,
      instructorImage: course.instructorImage,
      featured: course.featured,
    });
    
    setIsDialogOpen(true);
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="flex">
        <AdminSidebar activePath={location} />
        
        <div className="flex-1 p-8">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-3xl font-heading font-bold text-neutral-800">Manage Courses</h1>
              <p className="text-neutral-500">Add, edit, or remove courses from your catalog</p>
            </div>
            
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-primary hover:bg-primary-dark">
                  <Plus className="mr-2 h-4 w-4" /> Add New Course
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle>{isEditMode ? 'Edit Course' : 'Add New Course'}</DialogTitle>
                  <DialogDescription>
                    {isEditMode ? 'Update the details of this course.' : 'Fill in the details to add a new course to your catalog.'}
                  </DialogDescription>
                </DialogHeader>
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-4">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Title</FormLabel>
                            <FormControl>
                              <Input placeholder="Course title" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="slug"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Slug</FormLabel>
                            <FormControl>
                              <Input placeholder="course-slug" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Course description" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="price"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Price ($)</FormLabel>
                            <FormControl>
                              <Input type="number" min="0" step="0.01" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="duration"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Duration</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. 8 Weeks" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="image"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Course Image URL</FormLabel>
                          <FormControl>
                            <Input placeholder="https://example.com/image.jpg" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="categoryId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category</FormLabel>
                          <Select 
                            onValueChange={(value) => field.onChange(parseInt(value))}
                            defaultValue={field.value.toString()}
                            value={field.value.toString()}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select a category" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {isLoadingCategories ? (
                                <div className="flex items-center justify-center p-2">
                                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                                  Loading...
                                </div>
                              ) : (
                                categories.map((category: any) => (
                                  <SelectItem key={category.id} value={category.id.toString()}>
                                    {category.name}
                                  </SelectItem>
                                ))
                              )}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="instructorName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Instructor Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Full name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="instructorTitle"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Instructor Title</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. Tajweed Instructor" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="instructorImage"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Instructor Image URL</FormLabel>
                          <FormControl>
                            <Input placeholder="https://example.com/image.jpg" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="featured"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">Featured Course</FormLabel>
                            <FormDescription>
                              Display this course on the homepage featured section
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <DialogFooter>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setIsDialogOpen(false)}
                      >
                        Cancel
                      </Button>
                      <Button 
                        type="submit" 
                        className="bg-primary hover:bg-primary-dark"
                        disabled={addCourseMutation.isPending || editCourseMutation.isPending}
                      >
                        {(addCourseMutation.isPending || editCourseMutation.isPending) && (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        )}
                        {isEditMode ? 'Update Course' : 'Add Course'}
                      </Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
          
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="mb-6">
              <TabsTrigger value="all">All Courses</TabsTrigger>
              <TabsTrigger value="featured">Featured</TabsTrigger>
              {!isLoadingCategories && categories.map((category: any) => (
                <TabsTrigger key={category.id} value={category.id.toString()}>
                  {category.name}
                </TabsTrigger>
              ))}
            </TabsList>
            
            <TabsContent value="all">
              <Card>
                <CardContent className="p-6">
                  {isLoadingCourses ? (
                    <div className="flex items-center justify-center h-64">
                      <Loader2 className="h-8 w-8 text-primary animate-spin" />
                      <span className="ml-2">Loading courses...</span>
                    </div>
                  ) : courses && courses.length > 0 ? (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Title</TableHead>
                            <TableHead>Category</TableHead>
                            <TableHead>Price</TableHead>
                            <TableHead>Duration</TableHead>
                            <TableHead>Featured</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {courses.map((course: any) => (
                            <TableRow key={course.id}>
                              <TableCell className="font-medium">{course.title}</TableCell>
                              <TableCell>{course.categoryName || 'Uncategorized'}</TableCell>
                              <TableCell>${(course.price / 100).toFixed(2)}</TableCell>
                              <TableCell>{course.duration}</TableCell>
                              <TableCell>
                                {course.featured ? (
                                  <CheckCircle className="h-5 w-5 text-green-600" />
                                ) : (
                                  <AlertCircle className="h-5 w-5 text-neutral-300" />
                                )}
                              </TableCell>
                              <TableCell className="text-right">
                                <Button
                                  onClick={() => editCourse(course)}
                                  variant="ghost"
                                  size="sm"
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <div className="w-16 h-16 bg-neutral-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <AlertCircle className="h-8 w-8 text-neutral-400" />
                      </div>
                      <h3 className="text-lg font-heading font-bold text-neutral-600 mb-2">No Courses Found</h3>
                      <p className="text-neutral-500 mb-6">Add your first course to get started.</p>
                      <Button
                        onClick={() => setIsDialogOpen(true)}
                        className="bg-primary hover:bg-primary-dark"
                      >
                        <Plus className="mr-2 h-4 w-4" /> Add Course
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="featured">
              <Card>
                <CardContent className="p-6">
                  {isLoadingCourses ? (
                    <div className="flex items-center justify-center h-64">
                      <Loader2 className="h-8 w-8 text-primary animate-spin" />
                      <span className="ml-2">Loading featured courses...</span>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Title</TableHead>
                            <TableHead>Category</TableHead>
                            <TableHead>Price</TableHead>
                            <TableHead>Duration</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {courses.filter((course: any) => course.featured).map((course: any) => (
                            <TableRow key={course.id}>
                              <TableCell className="font-medium">{course.title}</TableCell>
                              <TableCell>{course.categoryName || 'Uncategorized'}</TableCell>
                              <TableCell>${(course.price / 100).toFixed(2)}</TableCell>
                              <TableCell>{course.duration}</TableCell>
                              <TableCell className="text-right">
                                <Button
                                  onClick={() => editCourse(course)}
                                  variant="ghost"
                                  size="sm"
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            {!isLoadingCategories && categories.map((category: any) => (
              <TabsContent key={category.id} value={category.id.toString()}>
                <Card>
                  <CardContent className="p-6">
                    {isLoadingCourses ? (
                      <div className="flex items-center justify-center h-64">
                        <Loader2 className="h-8 w-8 text-primary animate-spin" />
                        <span className="ml-2">Loading courses...</span>
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Title</TableHead>
                              <TableHead>Price</TableHead>
                              <TableHead>Duration</TableHead>
                              <TableHead>Featured</TableHead>
                              <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {courses
                              .filter((course: any) => course.categoryId === category.id)
                              .map((course: any) => (
                                <TableRow key={course.id}>
                                  <TableCell className="font-medium">{course.title}</TableCell>
                                  <TableCell>${(course.price / 100).toFixed(2)}</TableCell>
                                  <TableCell>{course.duration}</TableCell>
                                  <TableCell>
                                    {course.featured ? (
                                      <CheckCircle className="h-5 w-5 text-green-600" />
                                    ) : (
                                      <AlertCircle className="h-5 w-5 text-neutral-300" />
                                    )}
                                  </TableCell>
                                  <TableCell className="text-right">
                                    <Button
                                      onClick={() => editCourse(course)}
                                      variant="ghost"
                                      size="sm"
                                    >
                                      <Pencil className="h-4 w-4" />
                                    </Button>
                                  </TableCell>
                                </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </div>
    </div>
  );
}
