import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import AdminSidebar from '@/components/admin/sidebar';
import { CheckCircle2, XCircle, Clock, Eye, ChevronLeft } from 'lucide-react';

export default function AdminStudentApplications() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string | null>(null);
  const [viewApplication, setViewApplication] = useState<any | null>(null);
  const [statusDialogOpen, setStatusDialogOpen] = useState(false);
  const [newStatus, setNewStatus] = useState('');
  const [notes, setNotes] = useState('');
  
  // Scroll to the top on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Fetch all student applications
  const { data: applications = [], isLoading } = useQuery({
    queryKey: ['/api/student-applications'],
  });

  // Fetch all courses for reference
  const { data: courses = [] } = useQuery({
    queryKey: ['/api/courses'],
  });

  // Mutation for updating application status
  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status, notes }: { id: number; status: string; notes?: string }) => {
      const res = await apiRequest('PUT', `/api/student-applications/${id}/status`, { status, notes });
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Status updated",
        description: `Application status has been updated to ${newStatus}`,
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/student-applications'] });
      setStatusDialogOpen(false);
      setNotes('');
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update status",
        description: error.message || "An error occurred while updating the status",
        variant: "destructive",
      });
    },
  });

  // Filter applications based on search term and selected status
  const filteredApplications = applications.filter((app: any) => {
    const matchesSearch = !searchTerm || 
      app.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.courseName.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = !selectedStatus || app.status === selectedStatus;
    
    return matchesSearch && matchesStatus;
  });

  // Function to get the badge color based on status
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="bg-amber-100 text-amber-800 hover:bg-amber-100">Pending</Badge>;
      case 'enrolled':
        return <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">Enrolled</Badge>;
      case 'rejected':
        return <Badge variant="outline" className="bg-red-100 text-red-800 hover:bg-red-100">Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  // Function to handle opening the status update dialog
  const handleUpdateStatus = (application: any) => {
    setViewApplication(application);
    setNewStatus(application.status);
    setNotes(application.notes || '');
    setStatusDialogOpen(true);
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="flex">
        <AdminSidebar activePath={location} />
        
        <div className="flex-1 p-8">
          <div className="mb-6">
            <Button 
              variant="ghost" 
              className="mb-2" 
              onClick={() => setLocation('/admin/applications')}
            >
              <ChevronLeft className="h-4 w-4 mr-2" /> Back to Applications
            </Button>
            <h1 className="text-3xl font-heading font-bold text-neutral-800">Student Applications</h1>
            <p className="text-neutral-500">Review and manage student enrollment applications</p>
          </div>
          
          <div className="mb-6 flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <Input
                placeholder="Search by name, email, or course..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-md"
              />
            </div>
            <div>
              <Select
                value={selectedStatus || ""}
                onValueChange={(value) => setSelectedStatus(value || null)}
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">All Statuses</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="enrolled">Enrolled</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Card>
            <CardContent className="p-6">
              {isLoading ? (
                <div className="py-32 flex items-center justify-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
                </div>
              ) : filteredApplications.length > 0 ? (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Course</TableHead>
                        <TableHead>Date Applied</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredApplications.map((application: any) => (
                        <TableRow key={application.id}>
                          <TableCell className="font-medium">
                            {application.firstName} {application.lastName}
                          </TableCell>
                          <TableCell>{application.email}</TableCell>
                          <TableCell>{application.courseName}</TableCell>
                          <TableCell>
                            {new Date(application.createdAt).toLocaleDateString('en-US', {
                              year: 'numeric',
                              month: 'short',
                              day: 'numeric'
                            })}
                          </TableCell>
                          <TableCell>
                            {getStatusBadge(application.status)}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setViewApplication(application);
                                handleUpdateStatus(application);
                              }}
                            >
                              <Eye className="mr-1 h-4 w-4" /> View
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="py-32 text-center">
                  <div className="w-16 h-16 bg-neutral-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Clock className="h-8 w-8 text-neutral-400" />
                  </div>
                  <h3 className="text-lg font-heading font-bold text-neutral-600 mb-2">No Applications Found</h3>
                  <p className="text-neutral-500">
                    {searchTerm || selectedStatus
                      ? "No applications match your search criteria. Try adjusting your filters."
                      : "There are no student applications at this time."}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* Application Details Dialog */}
          {viewApplication && (
            <Dialog open={statusDialogOpen} onOpenChange={setStatusDialogOpen}>
              <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                  <DialogTitle>Student Application Details</DialogTitle>
                  <DialogDescription>
                    Review the application and update the status as needed.
                  </DialogDescription>
                </DialogHeader>
                
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-neutral-500">First Name</Label>
                      <div className="font-medium">{viewApplication.firstName}</div>
                    </div>
                    <div>
                      <Label className="text-neutral-500">Last Name</Label>
                      <div className="font-medium">{viewApplication.lastName}</div>
                    </div>
                  </div>
                  
                  <div>
                    <Label className="text-neutral-500">Email</Label>
                    <div className="font-medium">{viewApplication.email}</div>
                  </div>
                  
                  <div>
                    <Label className="text-neutral-500">Phone</Label>
                    <div className="font-medium">{viewApplication.phone}</div>
                  </div>
                  
                  <div>
                    <Label className="text-neutral-500">Course</Label>
                    <div className="font-medium">{viewApplication.courseName}</div>
                  </div>
                  
                  {viewApplication.message && (
                    <div>
                      <Label className="text-neutral-500">Additional Message</Label>
                      <div className="mt-1 p-3 bg-neutral-50 rounded-md text-neutral-600">
                        {viewApplication.message}
                      </div>
                    </div>
                  )}
                  
                  <div className="mt-4">
                    <Label htmlFor="status">Update Status</Label>
                    <Select
                      value={newStatus}
                      onValueChange={setNewStatus}
                    >
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="Select a status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">
                          <div className="flex items-center">
                            <Clock className="mr-2 h-4 w-4 text-amber-500" />
                            Pending Review
                          </div>
                        </SelectItem>
                        <SelectItem value="enrolled">
                          <div className="flex items-center">
                            <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
                            Enroll Student
                          </div>
                        </SelectItem>
                        <SelectItem value="rejected">
                          <div className="flex items-center">
                            <XCircle className="mr-2 h-4 w-4 text-red-500" />
                            Reject Application
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="notes">Admin Notes</Label>
                    <Textarea
                      id="notes"
                      placeholder="Add any notes about this application..."
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      className="mt-1"
                    />
                  </div>
                </div>
                
                <DialogFooter>
                  <Button 
                    variant="outline" 
                    onClick={() => setStatusDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={() => updateStatusMutation.mutate({
                      id: viewApplication.id,
                      status: newStatus,
                      notes: notes,
                    })}
                    disabled={updateStatusMutation.isPending}
                    className={
                      newStatus === 'enrolled' 
                        ? 'bg-green-600 hover:bg-green-700'
                        : newStatus === 'rejected'
                          ? 'bg-red-600 hover:bg-red-700'
                          : 'bg-primary hover:bg-primary-dark'
                    }
                  >
                    {updateStatusMutation.isPending ? 'Updating...' : 'Update Status'}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>
    </div>
  );
}
