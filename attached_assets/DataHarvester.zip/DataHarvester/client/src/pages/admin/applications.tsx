import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import AdminSidebar from '@/components/admin/sidebar';
import { ExternalLink } from 'lucide-react';
import { Link } from 'wouter';

export default function AdminApplications() {
  const [location] = useLocation();

  // Scroll to the top on mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="flex">
        <AdminSidebar activePath={location} />
        
        <div className="flex-1 p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-heading font-bold text-neutral-800">Manage Applications</h1>
            <p className="text-neutral-500">View and process student and career applications</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="overflow-hidden">
              <div className="h-40 bg-primary-light pattern-overlay flex items-center justify-center">
                <div className="h-20 w-20 bg-white rounded-full flex items-center justify-center">
                  <i className="fas fa-user-graduate text-3xl text-primary"></i>
                </div>
              </div>
              <CardContent className="p-6">
                <h2 className="text-2xl font-heading font-bold text-neutral-700 mb-3">Student Applications</h2>
                <p className="text-neutral-500 mb-6">
                  Review and manage applications from students who want to enroll in your courses. Approve qualified students and send welcome emails.
                </p>
                <Link href="/admin/student-applications">
                  <Button className="w-full bg-primary hover:bg-primary-dark">
                    Manage Student Applications
                    <ExternalLink className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
            
            <Card className="overflow-hidden">
              <div className="h-40 bg-secondary-light pattern-overlay flex items-center justify-center">
                <div className="h-20 w-20 bg-white rounded-full flex items-center justify-center">
                  <i className="fas fa-user-tie text-3xl text-secondary"></i>
                </div>
              </div>
              <CardContent className="p-6">
                <h2 className="text-2xl font-heading font-bold text-neutral-700 mb-3">Career Applications</h2>
                <p className="text-neutral-500 mb-6">
                  Review job applications from potential instructors and staff. Schedule interviews and manage the hiring process efficiently.
                </p>
                <Link href="/admin/career-applications">
                  <Button className="w-full bg-secondary hover:bg-secondary-dark">
                    Manage Career Applications
                    <ExternalLink className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
          
          <div className="mt-8">
            <Card>
              <CardContent className="p-6">
                <h2 className="text-xl font-heading font-bold text-neutral-700 mb-4">Application Processing Guide</h2>
                
                <div className="space-y-6">
                  <div className="border-l-4 border-primary pl-4">
                    <h3 className="font-heading font-bold text-neutral-600 mb-2">Student Applications</h3>
                    <ol className="list-decimal ml-4 space-y-2 text-neutral-500">
                      <li>Review the student's personal information and course selection</li>
                      <li>Verify any prerequisites if applicable</li>
                      <li>Approve suitable candidates and assign them to the appropriate course</li>
                      <li>Send a welcome email with course access information</li>
                      <li>Reject applications that don't meet criteria with a polite explanation</li>
                    </ol>
                  </div>
                  
                  <div className="border-l-4 border-secondary pl-4">
                    <h3 className="font-heading font-bold text-neutral-600 mb-2">Career Applications</h3>
                    <ol className="list-decimal ml-4 space-y-2 text-neutral-500">
                      <li>Review the applicant's qualifications, experience, and certifications</li>
                      <li>Check the position they're applying for and assess suitability</li>
                      <li>Schedule interviews for promising candidates</li>
                      <li>Request teaching demonstrations for instructor positions</li>
                      <li>Make hiring decisions and send appropriate notifications</li>
                    </ol>
                  </div>
                  
                  <div className="bg-neutral-100 p-4 rounded-lg">
                    <h3 className="font-heading font-bold text-neutral-600 mb-2">Best Practices</h3>
                    <ul className="list-disc ml-4 space-y-1 text-neutral-500">
                      <li>Respond to all applications within 7 days</li>
                      <li>Be consistent in your evaluation criteria</li>
                      <li>Keep detailed notes on each application for future reference</li>
                      <li>Consider diversity when building your teaching team</li>
                      <li>Always provide constructive feedback to rejected applicants</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
