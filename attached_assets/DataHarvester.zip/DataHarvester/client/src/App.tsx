import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

// Layouts
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";

// Pages
import Home from "@/pages/home";
import Courses from "@/pages/courses";
import About from "@/pages/about";
import Career from "@/pages/career";
import Contact from "@/pages/contact";
import Login from "@/pages/auth/login";
import Signup from "@/pages/auth/signup";
import AdminDashboard from "@/pages/admin/dashboard";
import AdminCourses from "@/pages/admin/courses";
import AdminApplications from "@/pages/admin/applications";
import AdminStudentApplications from "@/pages/admin/student-applications";
import AdminCareerApplications from "@/pages/admin/career-applications";
import AdminMessages from "@/pages/admin/messages";
import AdminSettings from "@/pages/admin/settings";
import NotFound from "@/pages/not-found";

// Protected route component
import ProtectedRoute from "@/lib/protected-route";

function Router() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/courses" component={Courses} />
          <Route path="/about" component={About} />
          <Route path="/career" component={Career} />
          <Route path="/contact" component={Contact} />
          <Route path="/login" component={Login} />
          <Route path="/signup" component={Signup} />
          
          {/* Admin Routes - Protected */}
          <Route path="/admin">
            <ProtectedRoute>
              <AdminDashboard />
            </ProtectedRoute>
          </Route>
          <Route path="/admin/courses">
            <ProtectedRoute>
              <AdminCourses />
            </ProtectedRoute>
          </Route>
          <Route path="/admin/applications">
            <ProtectedRoute>
              <AdminApplications />
            </ProtectedRoute>
          </Route>
          <Route path="/admin/student-applications">
            <ProtectedRoute>
              <AdminStudentApplications />
            </ProtectedRoute>
          </Route>
          <Route path="/admin/career-applications">
            <ProtectedRoute>
              <AdminCareerApplications />
            </ProtectedRoute>
          </Route>
          <Route path="/admin/messages">
            <ProtectedRoute>
              <AdminMessages />
            </ProtectedRoute>
          </Route>
          <Route path="/admin/settings">
            <ProtectedRoute>
              <AdminSettings />
            </ProtectedRoute>
          </Route>
          
          {/* Fallback to 404 */}
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
