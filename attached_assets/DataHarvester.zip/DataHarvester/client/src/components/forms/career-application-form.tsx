import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { insertCareerApplicationSchema } from '@shared/schema';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';

// Extend the schema with more validation
const careerFormSchema = insertCareerApplicationSchema.extend({
  email: z.string().email({ message: 'Please enter a valid email address' }),
  phone: z.string().min(6, { message: 'Please enter a valid phone number' }),
  experience: z.coerce.number().min(0, { message: 'Experience must be a positive number' }),
  qualifications: z.string().min(20, { message: 'Please provide more details about your qualifications' }),
  resumeUrl: z.string().optional(),
});

// Create a type for our form values
type CareerFormValues = z.infer<typeof careerFormSchema>;

export default function CareerApplicationForm() {
  const { toast } = useToast();
  const [isSubmitSuccessful, setIsSubmitSuccessful] = useState(false);

  // Initialize the form
  const form = useForm<CareerFormValues>({
    resolver: zodResolver(careerFormSchema),
    defaultValues: {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      position: '',
      experience: 0,
      qualifications: '',
      resumeUrl: '',
    },
  });

  // Create mutation for submitting the form
  const submitMutation = useMutation({
    mutationFn: async (values: CareerFormValues) => {
      const res = await apiRequest('POST', '/api/career-applications', values);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: 'Application Submitted',
        description: 'Your application has been submitted successfully. We will contact you soon.',
      });
      form.reset();
      setIsSubmitSuccessful(true);
    },
    onError: (error: Error) => {
      toast({
        title: 'Submission Failed',
        description: error.message || 'An error occurred while submitting your application. Please try again.',
        variant: 'destructive',
      });
    },
  });

  // Submit handler
  function onSubmit(values: CareerFormValues) {
    submitMutation.mutate(values);
  }

  // If submission was successful, show a success message
  if (isSubmitSuccessful) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-center text-primary text-xl">Application Submitted</CardTitle>
          <CardDescription className="text-center">
            Thank you for your interest in joining our team.
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <p className="mb-4">
            We have received your application and will review it shortly. If your qualifications match our requirements, we'll contact you to schedule an interview.
          </p>
          <Button
            className="mt-4"
            onClick={() => setIsSubmitSuccessful(false)}
          >
            Submit Another Application
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Apply for a Position</CardTitle>
        <CardDescription>
          Fill out the form below to apply for a position at Alyusri Institute
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="firstName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>First Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Your first name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="lastName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Last Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Your last name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input placeholder="Your email address" type="email" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone</FormLabel>
                    <FormControl>
                      <Input placeholder="Your phone number" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="position"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Position</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select the position you are applying for" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Quran Teacher">Quran Teacher</SelectItem>
                      <SelectItem value="Arabic Teacher">Arabic Teacher</SelectItem>
                      <SelectItem value="Tajweed Instructor">Tajweed Instructor</SelectItem>
                      <SelectItem value="Islamic Studies Teacher">Islamic Studies Teacher</SelectItem>
                      <SelectItem value="Administrative Staff">Administrative Staff</SelectItem>
                      <SelectItem value="Content Creator">Content Creator</SelectItem>
                      <SelectItem value="Online Tutor">Online Tutor</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="experience"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Years of Experience</FormLabel>
                  <FormControl>
                    <Input type="number" min="0" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="qualifications"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Qualifications & Experience</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Describe your qualifications, education, certifications, and relevant experience"
                      rows={5}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="resumeUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Resume URL (Optional)</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Link to your resume, portfolio, or LinkedIn profile"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button
              type="submit"
              className="w-full"
              disabled={submitMutation.isPending}
            >
              {submitMutation.isPending ? 'Submitting...' : 'Submit Application'}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}