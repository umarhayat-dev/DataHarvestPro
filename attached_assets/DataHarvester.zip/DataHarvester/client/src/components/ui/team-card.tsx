export interface TeamMemberProps {
  name: string;
  title: string;
  bio: string;
  image: string;
  socialLinks?: {
    twitter?: string;
    linkedin?: string;
    facebook?: string;
    instagram?: string;
    youtube?: string;
  };
}

export default function TeamCard({ name, title, bio, image, socialLinks }: TeamMemberProps) {
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition text-center">
      <div className="h-48 overflow-hidden">
        <img 
          src={image} 
          alt={name} 
          className="w-full h-full object-cover" 
        />
      </div>
      <div className="p-6">
        <h3 className="font-heading text-xl font-bold text-neutral-700">{name}</h3>
        <p className="text-secondary text-sm">{title}</p>
        <p className="text-neutral-500 text-sm mt-3">{bio}</p>
        
        {socialLinks && (
          <div className="flex justify-center mt-4 space-x-3">
            {socialLinks.twitter && (
              <a href={socialLinks.twitter} className="text-neutral-400 hover:text-primary transition" target="_blank" rel="noopener noreferrer">
                <i className="fab fa-twitter"></i>
              </a>
            )}
            {socialLinks.linkedin && (
              <a href={socialLinks.linkedin} className="text-neutral-400 hover:text-primary transition" target="_blank" rel="noopener noreferrer">
                <i className="fab fa-linkedin-in"></i>
              </a>
            )}
            {socialLinks.facebook && (
              <a href={socialLinks.facebook} className="text-neutral-400 hover:text-primary transition" target="_blank" rel="noopener noreferrer">
                <i className="fab fa-facebook-f"></i>
              </a>
            )}
            {socialLinks.instagram && (
              <a href={socialLinks.instagram} className="text-neutral-400 hover:text-primary transition" target="_blank" rel="noopener noreferrer">
                <i className="fab fa-instagram"></i>
              </a>
            )}
            {socialLinks.youtube && (
              <a href={socialLinks.youtube} className="text-neutral-400 hover:text-primary transition" target="_blank" rel="noopener noreferrer">
                <i className="fab fa-youtube"></i>
              </a>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
