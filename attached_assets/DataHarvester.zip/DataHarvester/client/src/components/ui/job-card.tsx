export interface JobProps {
  title: string;
  type: string;
  description: string;
  labelType: string;
  requirements: string[];
}

export default function JobCard({ title, type, description, labelType, requirements }: JobProps) {
  return (
    <div className="bg-neutral-100 rounded-lg p-6 hover:shadow-md transition">
      <div className="flex justify-between items-start">
        <div>
          <h4 className="font-heading text-xl font-bold text-neutral-700">{title}</h4>
          <p className="text-secondary text-sm mt-1">{type}</p>
        </div>
        <span className="px-3 py-1 bg-primary-light/20 text-primary-dark text-xs font-medium rounded-full">
          {labelType}
        </span>
      </div>
      <p className="text-neutral-500 text-sm mt-3">
        {description}
      </p>
      <div className="flex flex-wrap gap-2 mt-4">
        {requirements.map((requirement, index) => (
          <span key={index} className="px-2 py-1 bg-white text-neutral-500 text-xs rounded">
            {requirement}
          </span>
        ))}
      </div>
    </div>
  );
}
