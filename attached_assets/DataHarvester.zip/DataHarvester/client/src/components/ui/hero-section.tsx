import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

export default function HeroSection() {
  return (
    <section id="home" className="relative overflow-hidden bg-gradient-to-r from-primary to-primary-dark">
      {/* Hero Content */}
      <div className="container mx-auto px-4 py-16 md:py-24">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="text-white space-y-6 max-w-lg">
            <div className="inline-block px-3 py-1 bg-white/10 rounded-full text-sm backdrop-blur-sm">
              <span className="text-white font-medium">Online Quran Education</span>
            </div>
            <h1 className="font-heading text-4xl md:text-5xl font-bold">
              Learn Quran From Expert Scholars Anywhere
            </h1>
            <p className="text-white/80 text-lg">
              Alyusr Institute offers comprehensive online Quranic education with personalized attention and flexible scheduling for students worldwide.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/courses">
                <Button className="w-full sm:w-auto px-6 py-3 bg-white text-primary font-medium rounded-md hover:bg-neutral-100 transition">
                  Explore Courses
                </Button>
              </Link>
              <Button className="w-full sm:w-auto px-6 py-3 bg-secondary text-white font-medium rounded-md hover:bg-secondary-dark transition">
                Start Free Trial
              </Button>
            </div>
            <div className="pt-6 flex items-center">
              <div className="flex -space-x-4">
                {/* Student profile images */}
                <img 
                  className="w-10 h-10 rounded-full border-2 border-white object-cover" 
                  src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&h=400" 
                  alt="Student profile" 
                />
                <img 
                  className="w-10 h-10 rounded-full border-2 border-white object-cover" 
                  src="https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&h=400" 
                  alt="Student profile" 
                />
                <img 
                  className="w-10 h-10 rounded-full border-2 border-white object-cover" 
                  src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&h=400" 
                  alt="Student profile" 
                />
              </div>
              <div className="ml-4">
                <p className="text-white text-sm font-medium">Join 2,500+ Students</p>
                <div className="flex items-center mt-1">
                  <div className="flex text-yellow-400">
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star-half-alt"></i>
                  </div>
                  <span className="ml-1 text-white/90 text-sm">4.8/5</span>
                </div>
              </div>
            </div>
          </div>
          <div className="relative hidden md:block">
            {/* A young Muslim student studying Quran */}
            <img 
              src="https://pixabay.com/get/gc97d89806bbdf8c067f487c68f117c6854f72db65aeef2eb54ef59a5df59a5bbc60e2855fc5645c5749ca72c5b83f6ea7e675ddca7e9506d366393195b714ab3_1280.jpg" 
              alt="Student studying Quran" 
              className="rounded-lg shadow-lg object-cover h-[500px]" 
            />
            {/* Decorative element */}
            <div className="absolute -right-8 -bottom-8 w-24 h-24 bg-secondary rounded-full flex items-center justify-center shadow-lg">
              <div className="font-arabic text-white text-2xl">بسم</div>
            </div>
          </div>
        </div>
      </div>
      {/* Decorative Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="pattern-overlay w-full h-full"></div>
      </div>
    </section>
  );
}
