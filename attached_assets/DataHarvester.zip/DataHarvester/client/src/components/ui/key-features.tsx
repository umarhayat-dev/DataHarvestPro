export default function KeyFeatures() {
  const features = [
    {
      icon: "fas fa-user-tie",
      title: "Qualified Teachers",
      description: "Learn from certified scholars with ijazah (certifications) in Quran recitation and Islamic studies.",
      borderColor: "border-primary"
    },
    {
      icon: "fas fa-clock",
      title: "Flexible Scheduling",
      description: "Choose class times that fit your schedule, with options available across all time zones.",
      borderColor: "border-secondary"
    },
    {
      icon: "fas fa-laptop",
      title: "Interactive Learning",
      description: "Engage with our custom digital tools designed specifically for Quranic education and Arabic learning.",
      borderColor: "border-accent"
    },
    {
      icon: "fas fa-certificate",
      title: "Certified Programs",
      description: "Complete your studies with recognized certifications that validate your Quranic knowledge.",
      borderColor: "border-primary-dark"
    }
  ];

  return (
    <section className="py-16 bg-neutral-100 pattern-overlay">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h6 className="text-secondary text-sm font-medium uppercase tracking-wider">Why Choose Us</h6>
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-neutral-600 mt-2">Key Features of Our Institute</h2>
          <p className="text-neutral-500 mt-4">Experience comprehensive Quranic education with our unique approach that combines traditional teachings with modern methods.</p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className={`bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition duration-300 border-t-4 ${feature.borderColor}`}
            >
              <div className="w-14 h-14 rounded-full bg-primary-light/20 flex items-center justify-center mb-4">
                <i className={`${feature.icon} text-primary-dark text-xl`}></i>
              </div>
              <h3 className="font-heading text-xl font-bold text-neutral-600">{feature.title}</h3>
              <p className="text-neutral-500 mt-2">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
