export default function ContactInfo() {
  return (
    <div className="bg-white rounded-xl p-8 shadow-md h-full">
      <h3 className="font-heading text-2xl font-bold text-neutral-600 mb-6">Contact Information</h3>
      <div className="space-y-8">
        <div className="flex items-start">
          <div className="w-12 h-12 rounded-full bg-primary-light/20 flex items-center justify-center mr-4 flex-shrink-0">
            <i className="fas fa-phone-alt text-primary text-xl"></i>
          </div>
          <div>
            <h4 className="font-heading text-lg font-bold text-neutral-600">Phone</h4>
            <p className="text-neutral-500 text-sm mt-1">+1 (555) 123-4567</p>
            <p className="text-neutral-500 text-sm">Available 9am - 6pm (GMT)</p>
          </div>
        </div>
        
        <div className="flex items-start">
          <div className="w-12 h-12 rounded-full bg-secondary-light/20 flex items-center justify-center mr-4 flex-shrink-0">
            <i className="fas fa-envelope text-secondary text-xl"></i>
          </div>
          <div>
            <h4 className="font-heading text-lg font-bold text-neutral-600">Email</h4>
            <p className="text-neutral-500 text-sm mt-1">info@alyusrinstitute.com</p>
            <p className="text-neutral-500 text-sm">support@alyusrinstitute.com</p>
          </div>
        </div>
        
        <div className="flex items-start">
          <div className="w-12 h-12 rounded-full bg-accent-light/20 flex items-center justify-center mr-4 flex-shrink-0">
            <i className="fas fa-globe text-accent text-xl"></i>
          </div>
          <div>
            <h4 className="font-heading text-lg font-bold text-neutral-600">Online Support</h4>
            <p className="text-neutral-500 text-sm mt-1">24/7 Live Chat Support</p>
            <p className="text-neutral-500 text-sm">Student Help Desk</p>
          </div>
        </div>
        
        <div className="pt-8 border-t border-neutral-200">
          <h4 className="font-heading text-lg font-bold text-neutral-600 mb-4">Follow Us</h4>
          <div className="flex space-x-4">
            <a href="#" className="w-10 h-10 rounded-full bg-[#1877F2] flex items-center justify-center text-white hover:opacity-90 transition">
              <i className="fab fa-facebook-f"></i>
            </a>
            <a href="#" className="w-10 h-10 rounded-full bg-[#1DA1F2] flex items-center justify-center text-white hover:opacity-90 transition">
              <i className="fab fa-twitter"></i>
            </a>
            <a href="#" className="w-10 h-10 rounded-full bg-[#E4405F] flex items-center justify-center text-white hover:opacity-90 transition">
              <i className="fab fa-instagram"></i>
            </a>
            <a href="#" className="w-10 h-10 rounded-full bg-[#CD201F] flex items-center justify-center text-white hover:opacity-90 transition">
              <i className="fab fa-youtube"></i>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
