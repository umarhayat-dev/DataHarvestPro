import { Link } from 'wouter';

export interface CourseProps {
  id: number;
  image: string;
  category: string;
  categoryColor: string;
  title: string;
  description: string;
  duration: string;
  rating: number;
  reviewCount: number;
  instructorName: string;
  instructorTitle: string;
  instructorImage: string;
  price: number;
}

export default function CourseCard({
  id,
  image,
  category,
  categoryColor,
  title,
  description,
  duration,
  rating,
  reviewCount,
  instructorName,
  instructorTitle,
  instructorImage,
  price
}: CourseProps) {
  return (
    <Link href={`/courses/${id}`}>
      <div className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition group cursor-pointer">
        {/* Course image */}
        <div className="h-48 overflow-hidden relative">
          <img 
            src={image} 
            alt={title} 
            className="w-full h-full object-cover group-hover:scale-105 transition duration-300" 
          />
          <div className={`absolute top-4 right-4 ${categoryColor} text-white text-xs font-bold uppercase px-2 py-1 rounded`}>
            {category}
          </div>
        </div>
        <div className="p-6">
          <div className="flex justify-between items-center mb-3">
            <span className="text-xs text-neutral-500">
              <i className="far fa-clock mr-1"></i> {duration}
            </span>
            <div className="flex items-center">
              <span className="text-yellow-400 mr-1">
                <i className="fas fa-star"></i>
              </span>
              <span className="text-neutral-600 text-sm">{(rating / 100).toFixed(1)} ({reviewCount})</span>
            </div>
          </div>
          <h3 className="font-heading text-xl font-bold text-neutral-700 mb-2">{title}</h3>
          <p className="text-neutral-500 text-sm mb-4">{description}</p>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              {/* Teacher profile image */}
              <img 
                className="w-10 h-10 rounded-full object-cover" 
                src={instructorImage} 
                alt={instructorName} 
              />
              <div className="ml-3">
                <p className="text-sm font-medium text-neutral-700">{instructorName}</p>
                <p className="text-xs text-neutral-500">{instructorTitle}</p>
              </div>
            </div>
            <span className="text-primary font-bold">${(price / 100).toFixed(2)}</span>
          </div>
        </div>
      </div>
    </Link>
  );
}
