export interface TestimonialProps {
  quote: string;
  name: string;
  title: string;
  image: string;
}

export default function TestimonialCard({ quote, name, title, image }: TestimonialProps) {
  return (
    <div className="bg-white rounded-xl p-6 shadow-lg relative">
      <div className="absolute -top-4 left-6">
        <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
          <i className="fas fa-quote-right text-white"></i>
        </div>
      </div>
      <div className="pt-4">
        <p className="text-neutral-600 italic">
          "{quote}"
        </p>
        <div className="flex items-center mt-6">
          <img className="w-12 h-12 rounded-full object-cover" src={image} alt={name} />
          <div className="ml-3">
            <h4 className="font-heading text-lg font-bold text-neutral-700">{name}</h4>
            <p className="text-neutral-500 text-sm">{title}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
