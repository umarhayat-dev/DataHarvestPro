import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

export default function CTASection() {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="bg-neutral-100 rounded-2xl p-8 md:p-12 text-center pattern-overlay relative overflow-hidden">
          {/* Islamic calligraphy image as decoration */}
          <div className="absolute top-0 left-0 w-32 h-32 opacity-10">
            <img 
              src="https://images.unsplash.com/photo-1584810359583-96fc3448beaa?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=200&h=200" 
              alt="Islamic calligraphy" 
              className="w-full h-full object-cover" 
            />
          </div>
          <div className="absolute bottom-0 right-0 w-32 h-32 opacity-10">
            <img 
              src="https://pixabay.com/get/g571f43587ae619e498939757a86a1baed9a572056546388ef51259a6c62c76e920aaed3762982042561243d2e030c196dba3450c52cb15de31f3fd3e82bb3fa0_1280.jpg" 
              alt="Islamic pattern" 
              className="w-full h-full object-cover" 
            />
          </div>
          
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-neutral-600 max-w-2xl mx-auto">
            Ready to Start Your Quranic Journey?
          </h2>
          <p className="text-neutral-500 mt-4 max-w-xl mx-auto">
            Take the first step towards a deeper understanding of the Quran. Join our global community of learners today.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="px-8 py-3 bg-primary text-white font-medium rounded-md hover:bg-primary-dark transition">
              Enroll Now
            </Button>
            <Button 
              variant="outline"
              className="px-8 py-3 text-primary font-medium rounded-md border border-primary hover:bg-neutral-100 transition"
            >
              Schedule a Free Trial
            </Button>
          </div>
          <div className="mt-8 flex items-center justify-center">
            <div className="flex -space-x-2 mr-3">
              {/* Student profile images */}
              <img 
                className="w-8 h-8 rounded-full border-2 border-white object-cover" 
                src="https://pixabay.com/get/g2c9f4d191f1ed312a5411f05cf15d1a9d0393b5e6ce4a1ac01c708987bb379b07b4c26fbba317f5dbd5f8b11b7e898a65debbb7aa74bddae2caecd5e0d0aff8c_1280.jpg" 
                alt="Student profile" 
              />
              <img 
                className="w-8 h-8 rounded-full border-2 border-white object-cover" 
                src="https://images.unsplash.com/photo-1463453091185-61582044d556?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=200&h=200" 
                alt="Student profile" 
              />
              <img 
                className="w-8 h-8 rounded-full border-2 border-white object-cover" 
                src="https://images.unsplash.com/photo-1543269664-56d93c1b41a6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=200&h=200" 
                alt="Student profile" 
              />
            </div>
            <span className="text-neutral-500 text-sm">Join 2,500+ students worldwide</span>
          </div>
        </div>
      </div>
    </section>
  );
}
