import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';
import { useEffect } from 'react';

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
  isAuthenticated: boolean;
  isAdmin: boolean;
  onLogout: () => void;
  isLoggingOut: boolean;
}

export default function MobileMenu({
  isOpen,
  onClose,
  isAuthenticated,
  isAdmin,
  onLogout,
  isLoggingOut
}: MobileMenuProps) {
  // Prevent scrolling when menu is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isOpen]);

  return (
    <div className={`md:hidden mobile-menu fixed top-0 left-0 bottom-0 w-4/5 max-w-xs bg-white shadow-lg z-50 pt-20 px-6 ${
      isOpen ? 'open' : ''
    }`}>
      <Button
        variant="ghost"
        size="sm"
        className="absolute top-6 right-6 text-neutral-600"
        onClick={onClose}
      >
        <X className="h-6 w-6" />
      </Button>
      <nav className="flex flex-col space-y-6">
        <Link href="/" className="text-primary font-medium hover:text-primary-dark transition" onClick={onClose}>
          Home
        </Link>
        <Link href="/courses" className="text-neutral-500 font-medium hover:text-primary transition" onClick={onClose}>
          Courses
        </Link>
        <Link href="/about" className="text-neutral-500 font-medium hover:text-primary transition" onClick={onClose}>
          About
        </Link>
        <Link href="/career" className="text-neutral-500 font-medium hover:text-primary transition" onClick={onClose}>
          Career
        </Link>
        <Link href="/contact" className="text-neutral-500 font-medium hover:text-primary transition" onClick={onClose}>
          Contact
        </Link>
        {isAuthenticated && isAdmin && (
          <Link href="/admin" className="text-secondary font-medium hover:text-secondary-dark transition" onClick={onClose}>
            Admin
          </Link>
        )}
        <div className="pt-4 border-t border-neutral-200">
          {isAuthenticated ? (
            <Button
              variant="outline"
              className="w-full mb-4 border-primary text-primary hover:bg-primary hover:text-white"
              onClick={() => {
                onLogout();
                onClose();
              }}
              disabled={isLoggingOut}
            >
              {isLoggingOut ? 'Logging out...' : 'Log Out'}
            </Button>
          ) : (
            <>
              <Link href="/login" onClick={onClose} className="w-full block mb-4">
                <Button
                  variant="outline"
                  className="w-full border-primary text-primary hover:bg-primary hover:text-white"
                >
                  Log In
                </Button>
              </Link>
              <Link href="/signup" onClick={onClose} className="w-full block">
                <Button className="w-full bg-primary text-white hover:bg-primary-dark">
                  Sign Up
                </Button>
              </Link>
            </>
          )}
        </div>
      </nav>
    </div>
  );
}
