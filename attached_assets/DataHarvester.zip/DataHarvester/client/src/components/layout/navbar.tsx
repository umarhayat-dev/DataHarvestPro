import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/use-auth';
import { Menu, X } from 'lucide-react';
import MobileMenu from './mobile-menu';

export default function Navbar() {
  const [location] = useLocation();
  const { user, isAuthenticated, logout } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <header className={`sticky top-0 z-50 bg-white transition-shadow duration-300 ${isScrolled ? 'shadow-md' : ''}`}>
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
              <span className="text-white font-arabic text-xl">ق</span>
            </div>
            <div>
              <h1 className="font-heading text-primary text-xl font-bold">Alyusr</h1>
              <p className="text-xs text-muted-foreground">Quran Institute</p>
            </div>
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <Link href="/" className={`${isActive('/') ? 'text-primary' : 'text-muted-foreground'} font-medium hover:text-primary transition`}>
              Home
            </Link>
            <Link href="/courses" className={`${isActive('/courses') ? 'text-primary' : 'text-muted-foreground'} font-medium hover:text-primary transition`}>
              Courses
            </Link>
            <Link href="/about" className={`${isActive('/about') ? 'text-primary' : 'text-muted-foreground'} font-medium hover:text-primary transition`}>
              About
            </Link>
            <Link href="/career" className={`${isActive('/career') ? 'text-primary' : 'text-muted-foreground'} font-medium hover:text-primary transition`}>
              Career
            </Link>
            <Link href="/contact" className={`${isActive('/contact') ? 'text-primary' : 'text-muted-foreground'} font-medium hover:text-primary transition`}>
              Contact
            </Link>
            {isAuthenticated && user?.isAdmin && (
              <Link href="/admin" className={`${isActive('/admin') ? 'text-secondary' : 'text-muted-foreground'} font-medium hover:text-secondary transition`}>
                Admin
              </Link>
            )}
          </nav>
          
          {/* CTA Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            {isAuthenticated ? (
              <Button 
                variant="outline"
                className="border-primary text-primary hover:bg-primary hover:text-white"
                onClick={() => logout.mutate()}
                disabled={logout.isPending}
              >
                {logout.isPending ? 'Logging out...' : 'Log Out'}
              </Button>
            ) : (
              <>
                <Link href="/login">
                  <Button 
                    variant="outline"
                    className="border-primary text-primary hover:bg-primary hover:text-white"
                  >
                    Log In
                  </Button>
                </Link>
                <Link href="/signup">
                  <Button className="bg-primary text-white hover:bg-primary-dark">
                    Sign Up
                  </Button>
                </Link>
              </>
            )}
          </div>
          
          {/* Mobile Menu Button */}
          <Button 
            variant="ghost" 
            size="sm" 
            className="md:hidden text-neutral-600" 
            onClick={() => setIsMobileMenuOpen(true)}
          >
            <Menu className="h-6 w-6" />
          </Button>
        </div>
      </div>
      
      {/* Mobile Navigation */}
      <MobileMenu 
        isOpen={isMobileMenuOpen} 
        onClose={() => setIsMobileMenuOpen(false)}
        isAuthenticated={isAuthenticated}
        isAdmin={user?.isAdmin || false}
        onLogout={() => logout.mutate()}
        isLoggingOut={logout.isPending}
      />
    </header>
  );
}
