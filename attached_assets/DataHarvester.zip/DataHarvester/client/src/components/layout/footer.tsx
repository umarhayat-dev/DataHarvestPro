import { Link } from 'wouter';

export default function Footer() {
  return (
    <footer className="bg-neutral-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <div className="h-10 w-10 rounded-full bg-white flex items-center justify-center">
                <span className="text-primary font-arabic text-xl">ق</span>
              </div>
              <div>
                <h1 className="font-heading text-white text-xl font-bold">Alyusr</h1>
                <p className="text-xs text-white/90">Quran Institute</p>
              </div>
            </div>
            <p className="text-white/90 text-sm mb-6">
              Providing authentic Quranic education online since 2008. Our mission is to make Islamic knowledge accessible to Muslims worldwide.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white/90 hover:text-white transition">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="text-white/90 hover:text-white transition">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="text-white/90 hover:text-white transition">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="text-white/90 hover:text-white transition">
                <i className="fab fa-youtube"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-heading text-lg font-bold mb-6">Programs</h3>
            <ul className="space-y-3 text-sm">
              <li><Link href="/courses" className="text-white/90 hover:text-white transition">Tajweed Rules</Link></li>
              <li><Link href="/courses" className="text-white/90 hover:text-white transition">Quran Memorization (Hifz)</Link></li>
              <li><Link href="/courses" className="text-white/90 hover:text-white transition">Quranic Arabic</Link></li>
              <li><Link href="/courses" className="text-white/90 hover:text-white transition">Quran Translation</Link></li>
              <li><Link href="/courses" className="text-white/90 hover:text-white transition">Islamic Studies</Link></li>
              <li><Link href="/courses" className="text-white/90 hover:text-white transition">Certificate Programs</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-heading text-lg font-bold mb-6">Quick Links</h3>
            <ul className="space-y-3 text-sm">
              <li><Link href="/about" className="text-white/90 hover:text-white transition">About Us</Link></li>
              <li><Link href="/courses" className="text-white/90 hover:text-white transition">Courses</Link></li>
              <li><Link href="/about" className="text-white/90 hover:text-white transition">Teachers</Link></li>
              <li><Link href="/#testimonials" className="text-white/90 hover:text-white transition">Testimonials</Link></li>
              <li><Link href="/career" className="text-white/90 hover:text-white transition">Career</Link></li>
              <li><Link href="/contact" className="text-white/90 hover:text-white transition">Contact</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-heading text-lg font-bold mb-6">Newsletter</h3>
            <p className="text-white/90 text-sm mb-4">
              Subscribe to our newsletter to receive updates and Islamic resources.
            </p>
            <form onSubmit={(e) => e.preventDefault()}>
              <div className="flex mb-3">
                <input 
                  type="email" 
                  placeholder="Your email address" 
                  className="w-full px-4 py-2 rounded-l-md focus:outline-none text-neutral-600" 
                />
                <button type="submit" className="bg-secondary text-white px-4 rounded-r-md hover:bg-secondary-dark transition">
                  <i className="fas fa-paper-plane"></i>
                </button>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="consent" className="mr-2" />
                <label htmlFor="consent" className="text-white/90 text-xs">
                  I agree to receive emails from Alyusr Institute
                </label>
              </div>
            </form>
          </div>
        </div>
        
        <div className="pt-8 mt-8 border-t border-white/20 text-center text-white/90 text-sm">
          <p>© {new Date().getFullYear()} Alyusr Quran Institute. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
