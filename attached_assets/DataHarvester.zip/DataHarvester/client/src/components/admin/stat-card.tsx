import { Card, CardContent } from '@/components/ui/card';

interface StatCardProps {
  title: string;
  value: number;
  icon: string;
  colorClass: string;
  change?: {
    value: string;
    text: string;
  };
}

export default function StatCard({ title, value, icon, colorClass, change }: StatCardProps) {
  return (
    <Card className="border-none shadow-sm">
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-neutral-500">{title}</p>
            <h4 className="text-2xl font-bold mt-1">{value}</h4>
            
            {change && (
              <div className="flex items-center mt-2 text-xs">
                <span className={change.value.startsWith('+') ? 'text-green-500' : 'text-red-500'}>
                  {change.value}
                </span>
                <span className="text-neutral-500 ml-1">{change.text}</span>
              </div>
            )}
          </div>
          
          <div className={`h-12 w-12 rounded-full flex items-center justify-center ${colorClass}`}>
            <i className={`${icon} text-lg`}></i>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}