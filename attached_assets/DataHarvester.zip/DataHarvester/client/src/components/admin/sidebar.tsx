import { Link } from 'wouter';
import { cn } from '@/lib/utils';
import {
  BarChart3,
  BookOpen,
  Users,
  UserCog,
  MessageSquare,
  Settings,
  LogOut,
  Home
} from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';

interface AdminSidebarProps {
  activePath: string;
}

export default function AdminSidebar({ activePath }: AdminSidebarProps) {
  const { logout: logoutMutation } = useAuth();

  const handleLogout = () => {
    if (logoutMutation && typeof logoutMutation.mutate === 'function') {
      logoutMutation.mutate();
    }
  };

  const menuItems = [
    {
      name: 'Dashboard',
      path: '/admin',
      icon: <BarChart3 className="h-5 w-5" />,
    },
    {
      name: 'Courses',
      path: '/admin/courses',
      icon: <BookOpen className="h-5 w-5" />,
    },
    {
      name: 'Applications',
      path: '/admin/applications',
      icon: <Users className="h-5 w-5" />,
    },
    {
      name: 'Student Applications',
      path: '/admin/student-applications',
      icon: <Users className="h-5 w-5" />,
    },
    {
      name: 'Career Applications',
      path: '/admin/career-applications',
      icon: <UserCog className="h-5 w-5" />,
    },
    {
      name: 'Messages',
      path: '/admin/messages',
      icon: <MessageSquare className="h-5 w-5" />,
    },
    {
      name: 'Settings',
      path: '/admin/settings',
      icon: <Settings className="h-5 w-5" />,
    },
  ];

  return (
    <div className="hidden md:block w-64 bg-neutral-800 min-h-screen sticky top-0">
      <div className="p-6 flex items-center gap-3 border-b border-neutral-700">
        <div className="h-10 w-10 bg-primary rounded-full flex items-center justify-center">
          <span className="text-white font-bold text-lg">AI</span>
        </div>
        <span className="text-white font-heading font-bold text-lg">Alyusri Admin</span>
      </div>
      
      <div className="py-6">
        <ul className="space-y-1 px-3">
          {menuItems.map((item) => (
            <li key={item.path}>
              <Link href={item.path}>
                <a
                  className={cn(
                    "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
                    activePath === item.path
                      ? "bg-primary/10 text-primary"
                      : "text-neutral-400 hover:text-white hover:bg-neutral-700/50"
                  )}
                >
                  {item.icon}
                  {item.name}
                </a>
              </Link>
            </li>
          ))}
        </ul>

        <div className="px-3 mt-6 pt-6 border-t border-neutral-700">
          <Link href="/">
            <a className="flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium text-neutral-400 hover:text-white hover:bg-neutral-700/50 transition-colors">
              <Home className="h-5 w-5" />
              Back to Website
            </a>
          </Link>
          
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium text-neutral-400 hover:text-white hover:bg-neutral-700/50 transition-colors"
          >
            <LogOut className="h-5 w-5" />
            Logout
          </button>
        </div>
      </div>
    </div>
  );
}