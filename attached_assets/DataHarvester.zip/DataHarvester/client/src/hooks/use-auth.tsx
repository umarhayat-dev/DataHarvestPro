import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export type User = {
  id: number;
  username: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  profileImageUrl?: string;
  isAdmin: boolean;
};

export function useAuth() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isRedirecting, setIsRedirecting] = useState(false);

  // Get current authenticated user
  const { data: user, isLoading, refetch } = useQuery<User | null>({
    queryKey: ['/api/user'],
    retry: false,
    onError: () => {
      // Silently fail - user is not logged in
      return null;
    },
  });

  // Login mutation
  const login = useMutation({
    mutationFn: async ({ username, password }: { username: string; password: string }) => {
      const res = await apiRequest('POST', '/api/login', { username, password });
      return await res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Login successful",
        description: `Welcome back, ${data.username}!`,
      });
      queryClient.setQueryData(['/api/user'], data);
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Login failed",
        description: error.message || "Please check your credentials and try again.",
        variant: "destructive",
      });
    },
  });

  // Register mutation
  const register = useMutation({
    mutationFn: async (userData: {
      username: string;
      password: string;
      email?: string;
      firstName?: string;
      lastName?: string;
    }) => {
      const res = await apiRequest('POST', '/api/register', userData);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Registration successful",
        description: "Your account has been created. Please log in.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Registration failed",
        description: error.message || "Please try again with different credentials.",
        variant: "destructive",
      });
    },
  });

  // Logout mutation
  const logout = useMutation({
    mutationFn: async () => {
      setIsRedirecting(true);
      const res = await apiRequest('POST', '/api/logout', {});
      return await res.json();
    },
    onSuccess: () => {
      queryClient.setQueryData(['/api/user'], null);
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      
      toast({
        title: "Logout successful",
        description: "You have been logged out.",
      });
      
      // Redirect to home page after logout
      window.location.href = '/';
    },
    onError: (error: Error) => {
      setIsRedirecting(false);
      toast({
        title: "Logout failed",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    },
  });

  return {
    user,
    isAuthenticated: !!user,
    isAdmin: user?.isAdmin ?? false,
    isLoading: isLoading || isRedirecting,
    login,
    register,
    logout,
    refetch,
  };
}
